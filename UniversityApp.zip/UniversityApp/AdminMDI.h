#pragma once
#include "AdminManageStudents.h"
#include "ManageFaculty.h"
#include "ManageCourses.h"
#include "FinancialsManage.h"
#include "GenerateReport.h"

namespace UniversityApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for AdminMDI
	/// </summary>
	public ref class AdminMDI : public System::Windows::Forms::Form
	{
	public:
		AdminMDI(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~AdminMDI()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::MenuStrip^ menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^ adminDashboardToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ manageFacultyToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ manageCoursesToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ generateReportsToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ manageFinancialsToolStripMenuItem;
	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(AdminMDI::typeid));
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->adminDashboardToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->manageFacultyToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->manageCoursesToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->generateReportsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->manageFinancialsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->menuStrip1->SuspendLayout();
			this->SuspendLayout();
			// 
			// menuStrip1
			// 
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(5) {
				this->adminDashboardToolStripMenuItem,
					this->manageFacultyToolStripMenuItem, this->manageCoursesToolStripMenuItem, this->generateReportsToolStripMenuItem, this->manageFinancialsToolStripMenuItem
			});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(670, 24);
			this->menuStrip1->TabIndex = 0;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// adminDashboardToolStripMenuItem
			// 
			this->adminDashboardToolStripMenuItem->Name = L"adminDashboardToolStripMenuItem";
			this->adminDashboardToolStripMenuItem->Size = System::Drawing::Size(111, 20);
			this->adminDashboardToolStripMenuItem->Text = L"Manage Students";
			this->adminDashboardToolStripMenuItem->Click += gcnew System::EventHandler(this, &AdminMDI::adminDashboardToolStripMenuItem_Click);
			// 
			// manageFacultyToolStripMenuItem
			// 
			this->manageFacultyToolStripMenuItem->Name = L"manageFacultyToolStripMenuItem";
			this->manageFacultyToolStripMenuItem->Size = System::Drawing::Size(103, 20);
			this->manageFacultyToolStripMenuItem->Text = L"Manage Faculty";
			this->manageFacultyToolStripMenuItem->Click += gcnew System::EventHandler(this, &AdminMDI::manageFacultyToolStripMenuItem_Click);
			// 
			// manageCoursesToolStripMenuItem
			// 
			this->manageCoursesToolStripMenuItem->Name = L"manageCoursesToolStripMenuItem";
			this->manageCoursesToolStripMenuItem->Size = System::Drawing::Size(107, 20);
			this->manageCoursesToolStripMenuItem->Text = L"Manage Courses";
			this->manageCoursesToolStripMenuItem->Click += gcnew System::EventHandler(this, &AdminMDI::manageCoursesToolStripMenuItem_Click);
			// 
			// generateReportsToolStripMenuItem
			// 
			this->generateReportsToolStripMenuItem->Name = L"generateReportsToolStripMenuItem";
			this->generateReportsToolStripMenuItem->Size = System::Drawing::Size(109, 20);
			this->generateReportsToolStripMenuItem->Text = L"Generate Reports";
			this->generateReportsToolStripMenuItem->Click += gcnew System::EventHandler(this, &AdminMDI::generateReportsToolStripMenuItem_Click);
			// 
			// manageFinancialsToolStripMenuItem
			// 
			this->manageFinancialsToolStripMenuItem->Name = L"manageFinancialsToolStripMenuItem";
			this->manageFinancialsToolStripMenuItem->Size = System::Drawing::Size(117, 20);
			this->manageFinancialsToolStripMenuItem->Text = L"Manage Financials";
			this->manageFinancialsToolStripMenuItem->Click += gcnew System::EventHandler(this, &AdminMDI::manageFinancialsToolStripMenuItem_Click);
			// 
			// AdminMDI
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(670, 401);
			this->Controls->Add(this->menuStrip1);
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->MainMenuStrip = this->menuStrip1;
			this->Name = L"AdminMDI";
			this->Text = L"AdminMDI";
			this->Load += gcnew System::EventHandler(this, &AdminMDI::AdminMDI_Load);
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void adminDashboardToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {


		AdminManageStudents^ manage = gcnew AdminManageStudents();
		manage->Show();


	}
	private: System::Void AdminMDI_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void manageFacultyToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		
		ManageFaculty^ manage = gcnew ManageFaculty();
		manage->Show();

	}

private: System::Void manageCoursesToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
	ManageCourses^ manage = gcnew ManageCourses();
	manage->Show();


}
private: System::Void manageFinancialsToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {

	FinancialsManage^ manage = gcnew FinancialsManage();
	manage->Show();
}
private: System::Void generateReportsToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {


	GenerateReport^ manage = gcnew GenerateReport();
	manage->Show();

}
};
}