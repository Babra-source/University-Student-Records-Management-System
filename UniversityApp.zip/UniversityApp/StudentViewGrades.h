#pragma once

namespace UniversityApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for StudentViewGrades
	/// </summary>
	public ref class StudentViewGrades : public System::Windows::Forms::Form
	{
		MySqlConnection^ sqlConn = gcnew MySqlConnection();
		MySqlCommand^ sqlCmd = gcnew MySqlCommand();
		DataTable^ sqlDt = gcnew DataTable();
	private: System::Windows::Forms::Label^ TempStudentId;
	private: System::Windows::Forms::TextBox^ TempInput;
	private: System::Windows::Forms::Button^ btn_SubmitViewgrades;

		   MySqlDataAdapter^ sqlDtA = gcnew MySqlDataAdapter();
	public:
		StudentViewGrades(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~StudentViewGrades()
		{
			if (components)
			{
				delete components;
			}
		}

	private: System::Windows::Forms::MenuStrip^ menuStrip1;
	protected:
	private: System::Windows::Forms::ToolStripMenuItem^ viewSemesterGradesToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ transcriptToolStripMenuItem;
	private: System::Windows::Forms::DataGridView^ DataViewGrades;


	protected:











	private: System::ComponentModel::IContainer^ components;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->viewSemesterGradesToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->transcriptToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->DataViewGrades = (gcnew System::Windows::Forms::DataGridView());
			this->TempStudentId = (gcnew System::Windows::Forms::Label());
			this->TempInput = (gcnew System::Windows::Forms::TextBox());
			this->btn_SubmitViewgrades = (gcnew System::Windows::Forms::Button());
			this->menuStrip1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->DataViewGrades))->BeginInit();
			this->SuspendLayout();
			// 
			// menuStrip1
			// 
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {
				this->viewSemesterGradesToolStripMenuItem,
					this->transcriptToolStripMenuItem
			});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(478, 24);
			this->menuStrip1->TabIndex = 0;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// viewSemesterGradesToolStripMenuItem
			// 
			this->viewSemesterGradesToolStripMenuItem->Name = L"viewSemesterGradesToolStripMenuItem";
			this->viewSemesterGradesToolStripMenuItem->Size = System::Drawing::Size(134, 20);
			this->viewSemesterGradesToolStripMenuItem->Text = L"View Semester Grades";
			this->viewSemesterGradesToolStripMenuItem->Click += gcnew System::EventHandler(this, &StudentViewGrades::viewSemesterGradesToolStripMenuItem_Click);
			// 
			// transcriptToolStripMenuItem
			// 
			this->transcriptToolStripMenuItem->Name = L"transcriptToolStripMenuItem";
			this->transcriptToolStripMenuItem->Size = System::Drawing::Size(70, 20);
			this->transcriptToolStripMenuItem->Text = L"Transcript";
			// 
			// DataViewGrades
			// 
			this->DataViewGrades->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->DataViewGrades->Location = System::Drawing::Point(101, 133);
			this->DataViewGrades->Name = L"DataViewGrades";
			this->DataViewGrades->Size = System::Drawing::Size(240, 150);
			this->DataViewGrades->TabIndex = 1;
			this->DataViewGrades->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &StudentViewGrades::DataViewGrades_CellContentClick);
			// 
			// TempStudentId
			// 
			this->TempStudentId->AutoSize = true;
			this->TempStudentId->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->TempStudentId->Location = System::Drawing::Point(54, 55);
			this->TempStudentId->Name = L"TempStudentId";
			this->TempStudentId->Size = System::Drawing::Size(97, 20);
			this->TempStudentId->TabIndex = 2;
			this->TempStudentId->Text = L"StudentID ";
			// 
			// TempInput
			// 
			this->TempInput->Location = System::Drawing::Point(181, 55);
			this->TempInput->Name = L"TempInput";
			this->TempInput->Size = System::Drawing::Size(124, 20);
			this->TempInput->TabIndex = 3;
			// 
			// btn_SubmitViewgrades
			// 
			this->btn_SubmitViewgrades->Location = System::Drawing::Point(181, 90);
			this->btn_SubmitViewgrades->Name = L"btn_SubmitViewgrades";
			this->btn_SubmitViewgrades->Size = System::Drawing::Size(75, 23);
			this->btn_SubmitViewgrades->TabIndex = 4;
			this->btn_SubmitViewgrades->Text = L"Submit";
			this->btn_SubmitViewgrades->UseVisualStyleBackColor = true;
			this->btn_SubmitViewgrades->Click += gcnew System::EventHandler(this, &StudentViewGrades::btn_SubmitViewgrades_Click);
			// 
			// StudentViewGrades
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(478, 406);
			this->Controls->Add(this->btn_SubmitViewgrades);
			this->Controls->Add(this->TempInput);
			this->Controls->Add(this->TempStudentId);
			this->Controls->Add(this->DataViewGrades);
			this->Controls->Add(this->menuStrip1);
			this->MainMenuStrip = this->menuStrip1;
			this->Name = L"StudentViewGrades";
			this->Text = L"StudentViewGrades";
			this->Load += gcnew System::EventHandler(this, &StudentViewGrades::StudentViewGrades_Load);
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->DataViewGrades))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void StudentViewGrades_Load(System::Object^ sender, System::EventArgs^ e) {
		this->DataViewGrades->Visible = false;
		this->TempStudentId->Visible = false;
		this->TempInput->Visible = false;
		this->btn_SubmitViewgrades->Visible  = false;
	}

private: System::Void LoadGrades() {
	try {
		// Check if the student ID field is empty
		if (String::IsNullOrEmpty(TempInput->Text)) {
			MessageBox::Show("Please enter a valid Student ID.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Warning);
			return;
		}

		// Set the connection string before opening the connection
		sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";

		// Open the connection
		sqlConn->Open();

		// Use the logged-in student's ID (assuming TempInput contains it)
		String^ loggedInStudentId = TempInput->Text;

		// Modify the SQL query to fetch grades only for the particular student
		String^ CommandText = "SELECT c.course_name, g.grade "
			"FROM grades g "
			"JOIN enrollments e ON g.enrollment_id = e.enrollment_id "
			"JOIN courses c ON e.course_id = c.course_id "
			"WHERE e.student_id = @studentId";  // Filter by student ID

		// Create the SQL command
		sqlCmd = gcnew MySqlCommand(CommandText, sqlConn);
		sqlCmd->Parameters->AddWithValue("@studentId", loggedInStudentId);  // Use parameterized query to prevent SQL injection

		// Execute the query and get the data reader
		MySqlDataReader^ reader = sqlCmd->ExecuteReader();

		// Clear any existing rows in the DataGridView
		DataViewGrades->Rows->Clear();

		// Define columns if not already defined (add them programmatically)
		if (DataViewGrades->Columns->Count == 0) {
			DataGridViewColumn^ column1 = gcnew DataGridViewTextBoxColumn();
			column1->Name = "Course Name";
			DataViewGrades->Columns->Add(column1);

			DataGridViewColumn^ column2 = gcnew DataGridViewTextBoxColumn();
			column2->Name = "Grade";
			DataViewGrades->Columns->Add(column2);
		}

		// Check if the reader contains any data
		if (reader->HasRows) {
			while (reader->Read()) {
				// Add data from the reader to the DataGridView
				DataViewGrades->Rows->Add(reader["course_name"], reader["grade"]);
			}
		}
		else {
			MessageBox::Show("No grades found for this student.", "No Data", MessageBoxButtons::OK, MessageBoxIcon::Information);
		}

		// Close the reader and connection after data is fetched
		reader->Close();
		sqlConn->Close();
	}
	catch (Exception^ ex) {
		// Show an error message if any exception occurs
		MessageBox::Show("Error: " + ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
}

	private: System::Void viewSemesterGradesToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		this->TempInput->Visible = true;
		this->TempStudentId->Visible = true;
		this->DataViewGrades->Visible = true;
		this->btn_SubmitViewgrades->Visible = true;
		 LoadGrades();
	}
	private: System::Void DataViewGrades_CellContentClick(System::Object^ sender, System::Windows::Forms::DataGridViewCellEventArgs^ e) {
		
	}
private: System::Void btn_SubmitViewgrades_Click(System::Object^ sender, System::EventArgs^ e) {
	LoadGrades();
}
};
}
