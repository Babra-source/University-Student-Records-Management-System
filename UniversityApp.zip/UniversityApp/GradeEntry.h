#pragma once

namespace UniversityApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for GradeEntry
	/// </summary>
	public ref class GradeEntry : public System::Windows::Forms::Form
	{
		MySqlConnection^ sqlConn = gcnew MySqlConnection();
		MySqlCommand^ sqlCmd = gcnew MySqlCommand();
		DataTable^ sqlDt = gcnew DataTable();
		MySqlDataAdapter^ sqlDtA = gcnew MySqlDataAdapter();
	private: System::Windows::Forms::Button^ btnEditGrades;


	private: System::Windows::Forms::Button^ btn_DeleteGrade;
	private: System::Windows::Forms::DataGridView^ GridFacultyViewGrades;


	private: System::Windows::Forms::Label^ label3;

	public:
		MySqlDataReader^ sqlRd;
		GradeEntry(void)
		{
			InitializeComponent();

			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~GradeEntry()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::TextBox^ FacultyEnterStudentId;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::TextBox^ FacultyEnterGrade;
	private: System::Windows::Forms::Button^ BtnSubmitGrades;
	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->FacultyEnterStudentId = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->FacultyEnterGrade = (gcnew System::Windows::Forms::TextBox());
			this->BtnSubmitGrades = (gcnew System::Windows::Forms::Button());
			this->btnEditGrades = (gcnew System::Windows::Forms::Button());
			this->btn_DeleteGrade = (gcnew System::Windows::Forms::Button());
			this->GridFacultyViewGrades = (gcnew System::Windows::Forms::DataGridView());
			this->label3 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->GridFacultyViewGrades))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(12, 34);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(89, 20);
			this->label1->TabIndex = 0;
			this->label1->Text = L"StudentId";
			// 
			// FacultyEnterStudentId
			// 
			this->FacultyEnterStudentId->Location = System::Drawing::Point(113, 36);
			this->FacultyEnterStudentId->Name = L"FacultyEnterStudentId";
			this->FacultyEnterStudentId->Size = System::Drawing::Size(200, 20);
			this->FacultyEnterStudentId->TabIndex = 1;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(12, 107);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(59, 20);
			this->label2->TabIndex = 2;
			this->label2->Text = L"Grade";
			// 
			// FacultyEnterGrade
			// 
			this->FacultyEnterGrade->Location = System::Drawing::Point(113, 109);
			this->FacultyEnterGrade->Name = L"FacultyEnterGrade";
			this->FacultyEnterGrade->Size = System::Drawing::Size(192, 20);
			this->FacultyEnterGrade->TabIndex = 3;
			this->FacultyEnterGrade->TextChanged += gcnew System::EventHandler(this, &GradeEntry::FacultyEnterGrade_TextChanged);
			// 
			// BtnSubmitGrades
			// 
			this->BtnSubmitGrades->Location = System::Drawing::Point(132, 169);
			this->BtnSubmitGrades->Name = L"BtnSubmitGrades";
			this->BtnSubmitGrades->Size = System::Drawing::Size(113, 30);
			this->BtnSubmitGrades->TabIndex = 4;
			this->BtnSubmitGrades->Text = L"SubmitGrades";
			this->BtnSubmitGrades->UseVisualStyleBackColor = true;
			this->BtnSubmitGrades->Click += gcnew System::EventHandler(this, &GradeEntry::BtnSubmitGrades_Click);
			// 
			// btnEditGrades
			// 
			this->btnEditGrades->Location = System::Drawing::Point(309, 176);
			this->btnEditGrades->Name = L"btnEditGrades";
			this->btnEditGrades->Size = System::Drawing::Size(95, 23);
			this->btnEditGrades->TabIndex = 5;
			this->btnEditGrades->Text = L"Edit Grades";
			this->btnEditGrades->UseVisualStyleBackColor = true;
			this->btnEditGrades->Click += gcnew System::EventHandler(this, &GradeEntry::BtnEditGrade_Click);
			// 
			// btn_DeleteGrade
			// 
			this->btn_DeleteGrade->Location = System::Drawing::Point(496, 175);
			this->btn_DeleteGrade->Name = L"btn_DeleteGrade";
			this->btn_DeleteGrade->Size = System::Drawing::Size(75, 23);
			this->btn_DeleteGrade->TabIndex = 6;
			this->btn_DeleteGrade->Text = L"Delete";
			this->btn_DeleteGrade->UseVisualStyleBackColor = true;
			this->btn_DeleteGrade->Click += gcnew System::EventHandler(this, &GradeEntry::btn_DeleteGrade_Click);
			// 
			// GridFacultyViewGrades
			// 
			this->GridFacultyViewGrades->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->GridFacultyViewGrades->Location = System::Drawing::Point(31, 274);
			this->GridFacultyViewGrades->Name = L"GridFacultyViewGrades";
			this->GridFacultyViewGrades->Size = System::Drawing::Size(401, 255);
			this->GridFacultyViewGrades->TabIndex = 7;
			this->GridFacultyViewGrades->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &GradeEntry::GridFacultyViewGrades_CellContentClick);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft YaHei", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(31, 231);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(143, 22);
			this->label3->TabIndex = 8;
			this->label3->Text = L"Students Grades";
			// 
			// GradeEntry
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(702, 541);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->GridFacultyViewGrades);
			this->Controls->Add(this->btn_DeleteGrade);
			this->Controls->Add(this->btnEditGrades);
			this->Controls->Add(this->BtnSubmitGrades);
			this->Controls->Add(this->FacultyEnterGrade);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->FacultyEnterStudentId);
			this->Controls->Add(this->label1);
			this->Name = L"GradeEntry";
			this->Text = L"GradeEntry";
			this->Load += gcnew System::EventHandler(this, &GradeEntry::GradeEntry_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->GridFacultyViewGrades))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}


	private: System::Void LoadGrades() {
		try {

			// Set the connection string before opening the connection
			sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";

			// Open the connection
			sqlConn->Open();



			// Modify the SQL query to fetch grades only for the particular student
			String^ CommandText = "SELECT e.student_id, c.course_name, g.grade "
				"FROM grades g "
				"JOIN enrollments e ON g.enrollment_id = e.enrollment_id "
				"JOIN courses c ON e.course_id = c.course_id "
				"WHERE c.course_id = 1";  // Filter by course ID


			// Create the SQL command
			sqlCmd = gcnew MySqlCommand(CommandText, sqlConn);


			// Execute the query and get the data reader
			MySqlDataReader^ reader = sqlCmd->ExecuteReader();

			// Clear any existing rows in the DataGridView
			GridFacultyViewGrades->Rows->Clear();

			// Define columns if not already defined (add them programmatically)
			if (GridFacultyViewGrades->Columns->Count == 0) {

				DataGridViewColumn^ column1 = gcnew DataGridViewTextBoxColumn();
				column1->Name = "Student ID";
				GridFacultyViewGrades->Columns->Add(column1);
				DataGridViewColumn^ column2 = gcnew DataGridViewTextBoxColumn();
				column2->Name = "Course Name";
				GridFacultyViewGrades->Columns->Add(column2);

				DataGridViewColumn^ column3 = gcnew DataGridViewTextBoxColumn();
				column3->Name = "Grade";
				GridFacultyViewGrades->Columns->Add(column3);
			}

			// Check if the reader contains any data
			if (reader->HasRows) {
				while (reader->Read()) {
					// Add data from the reader to the DataGridView
					GridFacultyViewGrades->Rows->Add(reader["student_id"],reader["course_name"], reader["grade"]);
				}
			}
			else {
				MessageBox::Show("No grades found for this student.", "No Data", MessageBoxButtons::OK, MessageBoxIcon::Information);
			}

			// Close the reader and connection after data is fetched
			reader->Close();
			sqlConn->Close();
		}
		catch (Exception^ ex) {
			// Show an error message if any exception occurs
			MessageBox::Show("Error: " + ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
	}
	private:
		void InsertGrade(String^ studentId, String^ grade) {
			try {


				sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";
				sqlConn->Open();

				// Set up the SQL query to retrieve the enrollment_id from the Enrollment table
				String^ queryGetEnrollmentId = "SELECT enrollment_id FROM Enrollments WHERE student_id = @StudentId";
				sqlCmd = gcnew MySqlCommand(queryGetEnrollmentId, sqlConn);

				// Add parameters to prevent SQL injection
				sqlCmd->Parameters->Clear(); // Clear any existing parameters
				sqlCmd->Parameters->AddWithValue("@StudentId", studentId);

				// Execute the command to get enrollment_id
				MySqlDataReader^ sqlRd = sqlCmd->ExecuteReader();

				// Use 'using' to ensure proper disposal of the data reader
				if (sqlRd->Read()) {
					// Retrieve the enrollment_id
					String^ enrollmentId = sqlRd->GetString(0);
					sqlRd->Close();

					// Set up the SQL query to insert the grade into the Grade table
					String^ queryInsertGrade = "INSERT INTO Grades (enrollment_id, grade) VALUES (@EnrollmentId, @Grade)";
					sqlCmd->CommandText = queryInsertGrade;

					// Add parameters for the insertion
					sqlCmd->Parameters->Clear(); // Clear previous parameters
					sqlCmd->Parameters->AddWithValue("@EnrollmentId", enrollmentId);
					sqlCmd->Parameters->AddWithValue("@Grade", grade);

					MessageBox::Show("Enrollment ID: " + enrollmentId);
					MessageBox::Show("Grade: " + grade);


					// Execute the insertion into the Grade table
					sqlCmd->ExecuteNonQuery();

					// Display success message
					MessageBox::Show("Grade submitted successfully!");
				}
				else {
					// If studentId was not found
					MessageBox::Show("Student ID not found in the Enrollment table.");
				}
			}
			catch (Exception^ ex) {
				// Display any errors that occur
				MessageBox::Show("Error: " + ex->Message);
			}
			finally {
				// Ensure the connection is closed after the operation
				sqlConn->Close();
			}
	};




	


#pragma endregion
	private: System::Void BtnSubmitGrades_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ studentId = FacultyEnterStudentId->Text;
		String^ grade = FacultyEnterGrade->Text;

		// Call the InsertGrade method with the entered data
		InsertGrade(studentId, grade);
	


	}
private: System::Void GradeEntry_Load(System::Object^ sender, System::EventArgs^ e) {
	LoadGrades();
}
private: System::Void FacultyEnterGrade_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void BtnEditGrade_Click(System::Object^ sender, System::EventArgs^ e) {
	String^ studentId = FacultyEnterStudentId->Text;
	String^ newGrade = FacultyEnterGrade->Text;

	// Check if student ID or grade is empty
	if (studentId->Length == 0) {
		MessageBox::Show("Please fill in both the student ID");
		return;
	}

	String^ currentGrade;

	// Fetch the current grade of the student
	try {
		sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";
		sqlConn->Open();

		// Query to fetch the current grade
		String^ queryFetchGrade = "SELECT grade FROM Grades WHERE enrollment_id IN (SELECT enrollment_id FROM Enrollments WHERE student_id = @StudentId)";
		sqlCmd = gcnew MySqlCommand(queryFetchGrade, sqlConn);

		sqlCmd->Parameters->Clear(); // Clear any previous parameters
		sqlCmd->Parameters->AddWithValue("@StudentId", studentId);

		MySqlDataReader^ sqlRd = sqlCmd->ExecuteReader();

		if (sqlRd->Read()) {
			// Fetch the current grade
			currentGrade = sqlRd->GetString(0);
			MessageBox::Show("Current grade: " + currentGrade, "Previous Grade", MessageBoxButtons::OK, MessageBoxIcon::Information);
		}
		else {
			MessageBox::Show("No grade found for this student.");
			sqlRd->Close();
			return; // Exit if no grade is found
		}
		sqlRd->Close();
	}
	catch (Exception^ ex) {
		MessageBox::Show("Error: " + ex->Message);
		return;
	}

	// Proceed to update the grade
	try {
		
		String^ queryUpdateGrade = "UPDATE Grades SET grade = @Grade WHERE enrollment_id IN (SELECT enrollment_id FROM Enrollments WHERE student_id = @StudentId)";
		sqlCmd = gcnew MySqlCommand(queryUpdateGrade, sqlConn);

		sqlCmd->Parameters->Clear(); // Clear any existing parameters
		sqlCmd->Parameters->AddWithValue("@StudentId", studentId);
		sqlCmd->Parameters->AddWithValue("@Grade", newGrade);

		int rowsAffected = sqlCmd->ExecuteNonQuery();

		if (rowsAffected > 0) {
			MessageBox::Show("Grade updated successfully!");
		}
		else {
			MessageBox::Show("No records were updated. Please check the student ID.");
		}
	}
	catch (Exception^ ex) {
		MessageBox::Show("Error: " + ex->Message);
	}
	finally {
		sqlConn->Close();
	}
}

private: System::Void GridFacultyViewGrades_CellContentClick(System::Object^ sender, System::Windows::Forms::DataGridViewCellEventArgs^ e) {

	
}
private: System::Void btn_DeleteGrade_Click(System::Object^ sender, System::EventArgs^ e) {

	try {
		// Get the selected row in the DataGridView
		int selectedRowIndex = GridFacultyViewGrades->SelectedCells[0]->RowIndex;
		DataGridViewRow^ selectedRow = GridFacultyViewGrades->Rows[selectedRowIndex];

		// Get the StudentId from the selected row (assuming the first column contains the StudentId)
		String^ studentId = selectedRow->Cells["Student ID"]->Value->ToString();

		// Prepare the SQL query for deleting the grade
		String^ query = "DELETE FROM grades WHERE enrollment_id IN (SELECT enrollment_id FROM Enrollments WHERE student_id = @StudentId)";

		// Initialize the SQL commandAm
		sqlCmd->CommandText = query;
		sqlCmd->CommandType = CommandType::Text;
		

		// Add the StudentId parameter to the command
		sqlCmd->Parameters->Clear();
		sqlCmd->Parameters->AddWithValue("@StudentId", studentId);
		sqlConn->Open();
	
		int rowsAffected = sqlCmd->ExecuteNonQuery();

		if (rowsAffected > 0) {
			MessageBox::Show("Grade deleted successfully!");
		}
		else {
			MessageBox::Show("No record found with the given StudentId.");
		}

		// Reload the grades data into the DataGridView
		LoadGrades();
	}
	catch (Exception^ ex) {
		MessageBox::Show("Error: " + ex->Message);
	}
	finally {
		if (sqlConn->State == ConnectionState::Open) {
			sqlConn->Close();
		}

	};




}
};
}
