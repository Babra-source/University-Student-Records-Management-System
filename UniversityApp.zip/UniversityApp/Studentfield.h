#pragma once
#include "StudentViewGrades.h";
#include "CourseEnrollment.h";
#include "StudentTranscript.h";
#include "PayFeesForm.h"


namespace UniversityApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Studentfield
	/// </summary>
	public ref class Studentfield : public System::Windows::Forms::Form
	{
	public:
		Studentfield(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Studentfield()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ btn_Enroll;
	private: System::Windows::Forms::Button^ btnViewgrades;
	protected:

	protected:

	private: System::Windows::Forms::Button^ BtnPayFees;



	private: System::Windows::Forms::Button^ btn_VIewProfile;

	private: System::Windows::Forms::Label^ StudentLabel;
	private: System::Windows::Forms::Button^ Btn_Transcript;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Studentfield::typeid));
			this->btn_Enroll = (gcnew System::Windows::Forms::Button());
			this->btnViewgrades = (gcnew System::Windows::Forms::Button());
			this->BtnPayFees = (gcnew System::Windows::Forms::Button());
			this->btn_VIewProfile = (gcnew System::Windows::Forms::Button());
			this->StudentLabel = (gcnew System::Windows::Forms::Label());
			this->Btn_Transcript = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// btn_Enroll
			// 
			this->btn_Enroll->BackColor = System::Drawing::SystemColors::HotTrack;
			this->btn_Enroll->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_Enroll->Location = System::Drawing::Point(97, 117);
			this->btn_Enroll->Name = L"btn_Enroll";
			this->btn_Enroll->Size = System::Drawing::Size(111, 44);
			this->btn_Enroll->TabIndex = 0;
			this->btn_Enroll->Text = L"Enroll in courses ";
			this->btn_Enroll->UseVisualStyleBackColor = false;
			this->btn_Enroll->Click += gcnew System::EventHandler(this, &Studentfield::btn_Enroll_Click);
			// 
			// btnViewgrades
			// 
			this->btnViewgrades->BackColor = System::Drawing::SystemColors::HotTrack;
			this->btnViewgrades->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnViewgrades->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->btnViewgrades->Location = System::Drawing::Point(295, 117);
			this->btnViewgrades->Name = L"btnViewgrades";
			this->btnViewgrades->Size = System::Drawing::Size(104, 44);
			this->btnViewgrades->TabIndex = 1;
			this->btnViewgrades->Text = L"View grades";
			this->btnViewgrades->UseVisualStyleBackColor = false;
			this->btnViewgrades->Click += gcnew System::EventHandler(this, &Studentfield::btnViewgrades_Click);
			// 
			// BtnPayFees
			// 
			this->BtnPayFees->BackColor = System::Drawing::SystemColors::HotTrack;
			this->BtnPayFees->Location = System::Drawing::Point(454, 117);
			this->BtnPayFees->Name = L"BtnPayFees";
			this->BtnPayFees->Size = System::Drawing::Size(105, 44);
			this->BtnPayFees->TabIndex = 2;
			this->BtnPayFees->Text = L"Pay Fees";
			this->BtnPayFees->UseVisualStyleBackColor = false;
			this->BtnPayFees->Click += gcnew System::EventHandler(this, &Studentfield::BtnPayFees_Click);
			// 
			// btn_VIewProfile
			// 
			this->btn_VIewProfile->BackColor = System::Drawing::SystemColors::HotTrack;
			this->btn_VIewProfile->Cursor = System::Windows::Forms::Cursors::SizeAll;
			this->btn_VIewProfile->ForeColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->btn_VIewProfile->Location = System::Drawing::Point(346, 263);
			this->btn_VIewProfile->Name = L"btn_VIewProfile";
			this->btn_VIewProfile->Size = System::Drawing::Size(130, 46);
			this->btn_VIewProfile->TabIndex = 4;
			this->btn_VIewProfile->Text = L"View Profile ";
			this->btn_VIewProfile->UseVisualStyleBackColor = false;
			this->btn_VIewProfile->Click += gcnew System::EventHandler(this, &Studentfield::btn_VIewProfile_Click);
			// 
			// StudentLabel
			// 
			this->StudentLabel->AutoSize = true;
			this->StudentLabel->BackColor = System::Drawing::Color::Transparent;
			this->StudentLabel->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->StudentLabel->Location = System::Drawing::Point(255, 24);
			this->StudentLabel->Name = L"StudentLabel";
			this->StudentLabel->Size = System::Drawing::Size(265, 31);
			this->StudentLabel->TabIndex = 5;
			this->StudentLabel->Text = L"Student Dashboard";
			this->StudentLabel->Click += gcnew System::EventHandler(this, &Studentfield::label1_Click);
			// 
			// Btn_Transcript
			// 
			this->Btn_Transcript->BackColor = System::Drawing::SystemColors::HotTrack;
			this->Btn_Transcript->Location = System::Drawing::Point(131, 263);
			this->Btn_Transcript->Name = L"Btn_Transcript";
			this->Btn_Transcript->Size = System::Drawing::Size(117, 45);
			this->Btn_Transcript->TabIndex = 6;
			this->Btn_Transcript->Text = L"Transcript";
			this->Btn_Transcript->UseVisualStyleBackColor = false;
			this->Btn_Transcript->Click += gcnew System::EventHandler(this, &Studentfield::Btn_Transcript_Click);
			// 
			// Studentfield
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;
			this->ClientSize = System::Drawing::Size(771, 454);
			this->Controls->Add(this->Btn_Transcript);
			this->Controls->Add(this->StudentLabel);
			this->Controls->Add(this->btn_VIewProfile);
			this->Controls->Add(this->BtnPayFees);
			this->Controls->Add(this->btnViewgrades);
			this->Controls->Add(this->btn_Enroll);
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->Name = L"Studentfield";
			this->Text = L"Studentfield";
			this->Load += gcnew System::EventHandler(this, &Studentfield::Studentfield_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Studentfield_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void BtnPayFees_Click(System::Object^ sender, System::EventArgs^ e) {

		PayFeesForm^ feesForm = gcnew PayFeesForm();
		feesForm->Show();

	}
	private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void btn_Enroll_Click(System::Object^ sender, System::EventArgs^ e) {

		CourseEnrollment^ CourseForm = gcnew CourseEnrollment();
		CourseForm->Show();

	}
	private: System::Void btn_VIewProfile_Click(System::Object^ sender, System::EventArgs^ e) {

	
	}
	private: System::Void btnViewgrades_Click(System::Object^ sender, System::EventArgs^ e) {


		StudentViewGrades^ ViewGradesForm = gcnew StudentViewGrades();
		ViewGradesForm->Show();

	}
private: System::Void Btn_Transcript_Click(System::Object^ sender, System::EventArgs^ e) {

	StudentTranscript^ Transcript = gcnew StudentTranscript();
	Transcript->Show();

}
};
}
