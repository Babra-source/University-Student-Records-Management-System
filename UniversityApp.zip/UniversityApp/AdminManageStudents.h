#pragma once

namespace UniversityApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for AdminManageStudents
	/// </summary>
	public ref class AdminManageStudents : public System::Windows::Forms::Form
	{
		MySqlConnection^ sqlConn = gcnew MySqlConnection();
		MySqlCommand^ sqlCmd = gcnew MySqlCommand();
		DataTable^ sqlDt = gcnew DataTable();
		MySqlDataAdapter^ sqlDtA = gcnew MySqlDataAdapter();
	private: System::Windows::Forms::DateTimePicker^ AdminStudentDob;
	private: System::Windows::Forms::Label^ labelFirstName;
	private: System::Windows::Forms::TextBox^ StuLastName;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::TextBox^ StuEmail;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::Label^ label6;
	public:
		MySqlDataReader^ sqlRd;
		AdminManageStudents(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~AdminManageStudents()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	protected:
	private: System::Windows::Forms::Button^ btn_AddStudents;
	private: System::Windows::Forms::Button^ btn_EditInfo;
	private: System::Windows::Forms::Button^ btn_DeleteStudents;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::TextBox^ AdminStuFirstName;


	private: System::Windows::Forms::TextBox^ AdminAddMajor;






	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(AdminManageStudents::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->btn_AddStudents = (gcnew System::Windows::Forms::Button());
			this->btn_EditInfo = (gcnew System::Windows::Forms::Button());
			this->btn_DeleteStudents = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->AdminStuFirstName = (gcnew System::Windows::Forms::TextBox());
			this->AdminAddMajor = (gcnew System::Windows::Forms::TextBox());
			this->AdminStudentDob = (gcnew System::Windows::Forms::DateTimePicker());
			this->labelFirstName = (gcnew System::Windows::Forms::Label());
			this->StuLastName = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->StuEmail = (gcnew System::Windows::Forms::TextBox());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(161, 53);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(151, 20);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Manage Students";
			// 
			// btn_AddStudents
			// 
			this->btn_AddStudents->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_AddStudents->Location = System::Drawing::Point(29, 332);
			this->btn_AddStudents->Name = L"btn_AddStudents";
			this->btn_AddStudents->Size = System::Drawing::Size(111, 39);
			this->btn_AddStudents->TabIndex = 1;
			this->btn_AddStudents->Text = L"Add Students";
			this->btn_AddStudents->UseVisualStyleBackColor = true;
			this->btn_AddStudents->Click += gcnew System::EventHandler(this, &AdminManageStudents::btn_AddStudents_Click);
			// 
			// btn_EditInfo
			// 
			this->btn_EditInfo->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_EditInfo->Location = System::Drawing::Point(199, 332);
			this->btn_EditInfo->Name = L"btn_EditInfo";
			this->btn_EditInfo->Size = System::Drawing::Size(128, 39);
			this->btn_EditInfo->TabIndex = 2;
			this->btn_EditInfo->Text = L"Edits Students Info";
			this->btn_EditInfo->UseVisualStyleBackColor = true;
			this->btn_EditInfo->Click += gcnew System::EventHandler(this, &AdminManageStudents::btn_EditInfo_Click);
			// 
			// btn_DeleteStudents
			// 
			this->btn_DeleteStudents->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_DeleteStudents->Location = System::Drawing::Point(374, 336);
			this->btn_DeleteStudents->Name = L"btn_DeleteStudents";
			this->btn_DeleteStudents->Size = System::Drawing::Size(142, 35);
			this->btn_DeleteStudents->TabIndex = 3;
			this->btn_DeleteStudents->Text = L"Delete Student";
			this->btn_DeleteStudents->UseVisualStyleBackColor = true;
			this->btn_DeleteStudents->Click += gcnew System::EventHandler(this, &AdminManageStudents::btn_DeleteStudents_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(12, 95);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(63, 13);
			this->label2->TabIndex = 4;
			this->label2->Text = L"FirstName";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(12, 191);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(79, 13);
			this->label3->TabIndex = 5;
			this->label3->Text = L"Date of Birth";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(12, 263);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(42, 13);
			this->label4->TabIndex = 6;
			this->label4->Text = L"Major ";
			// 
			// AdminStuFirstName
			// 
			this->AdminStuFirstName->Location = System::Drawing::Point(136, 95);
			this->AdminStuFirstName->Name = L"AdminStuFirstName";
			this->AdminStuFirstName->Size = System::Drawing::Size(191, 20);
			this->AdminStuFirstName->TabIndex = 7;
			// 
			// AdminAddMajor
			// 
			this->AdminAddMajor->Location = System::Drawing::Point(133, 263);
			this->AdminAddMajor->Name = L"AdminAddMajor";
			this->AdminAddMajor->Size = System::Drawing::Size(191, 20);
			this->AdminAddMajor->TabIndex = 9;
			// 
			// AdminStudentDob
			// 
			this->AdminStudentDob->Location = System::Drawing::Point(133, 191);
			this->AdminStudentDob->Name = L"AdminStudentDob";
			this->AdminStudentDob->Size = System::Drawing::Size(200, 20);
			this->AdminStudentDob->TabIndex = 10;
			// 
			// labelFirstName
			// 
			this->labelFirstName->AutoSize = true;
			this->labelFirstName->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->labelFirstName->Location = System::Drawing::Point(12, 130);
			this->labelFirstName->Name = L"labelFirstName";
			this->labelFirstName->Size = System::Drawing::Size(63, 13);
			this->labelFirstName->TabIndex = 11;
			this->labelFirstName->Text = L"LastName";
			// 
			// StuLastName
			// 
			this->StuLastName->Location = System::Drawing::Point(133, 130);
			this->StuLastName->Name = L"StuLastName";
			this->StuLastName->Size = System::Drawing::Size(191, 20);
			this->StuLastName->TabIndex = 12;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(12, 165);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(37, 13);
			this->label5->TabIndex = 13;
			this->label5->Text = L"Email";
			// 
			// StuEmail
			// 
			this->StuEmail->Location = System::Drawing::Point(133, 165);
			this->StuEmail->Name = L"StuEmail";
			this->StuEmail->Size = System::Drawing::Size(200, 20);
			this->StuEmail->TabIndex = 14;
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(133, 230);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(194, 20);
			this->textBox1->TabIndex = 15;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(12, 230);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(106, 13);
			this->label6->TabIndex = 16;
			this->label6->Text = L"Default Password";
			// 
			// AdminManageStudents
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(566, 470);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->StuEmail);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->StuLastName);
			this->Controls->Add(this->labelFirstName);
			this->Controls->Add(this->AdminStudentDob);
			this->Controls->Add(this->AdminAddMajor);
			this->Controls->Add(this->AdminStuFirstName);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->btn_DeleteStudents);
			this->Controls->Add(this->btn_EditInfo);
			this->Controls->Add(this->btn_AddStudents);
			this->Controls->Add(this->label1);
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->Name = L"AdminManageStudents";
			this->Text = L"AdminManageStudents";
			this->Load += gcnew System::EventHandler(this, &AdminManageStudents::AdminManageStudents_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void AdminManageStudents_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void btn_AddStudents_Click(System::Object^ sender, System::EventArgs^ e) {

		// Connection string to the MySQL database
		sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";

		try {
			// Open the connection
			sqlConn->Open();

			// Retrieve input values
			String^ firstName = AdminStuFirstName->Text;
			String^ lastName = StuLastName->Text;
			String^ dob = AdminStudentDob->Value.ToString("yyyy-MM-dd");
			String^ major = AdminAddMajor->Text;
			String^ email = StuEmail->Text;
			String^ password = textBox1->Text; // Assuming textBox1 is for the password

			if (String::IsNullOrEmpty(firstName) || String::IsNullOrEmpty(lastName) ||
				String::IsNullOrEmpty(email) || String::IsNullOrEmpty(password) || String::IsNullOrEmpty(major)) {
				MessageBox::Show("Please fill in all required fields.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
				return;
			}

			// Insert into users table
			String^ insertUserQuery = "INSERT INTO users (first_name, last_name, email, password, role) VALUES (@FirstName, @LastName, @Email, @Password, 'student')";
			sqlCmd->Connection = sqlConn;
			sqlCmd->CommandText = insertUserQuery;
			sqlCmd->Parameters->Clear();
			sqlCmd->Parameters->AddWithValue("@FirstName", firstName);
			sqlCmd->Parameters->AddWithValue("@LastName", lastName);
			sqlCmd->Parameters->AddWithValue("@Email", email);
			sqlCmd->Parameters->AddWithValue("@Password", password);
			sqlCmd->ExecuteNonQuery();

			int userId;
			sqlCmd->CommandText = "SELECT LAST_INSERT_ID()";
			userId = Convert::ToInt32(sqlCmd->ExecuteScalar());

			// Insert into students table
			String^ insertStudentQuery = "INSERT INTO students (student_id, dob, major) VALUES (@UserId, @Dob, @Major)";
			sqlCmd->CommandText = insertStudentQuery;
			sqlCmd->Parameters->Clear();
			sqlCmd->Parameters->AddWithValue("@UserId", userId);
			sqlCmd->Parameters->AddWithValue("@Dob", dob);
			sqlCmd->Parameters->AddWithValue("@Major", major);
			sqlCmd->ExecuteNonQuery();

			// Notify the admin
			MessageBox::Show("Student added successfully!", "Success", MessageBoxButtons::OK, MessageBoxIcon::Information);
		}
		catch (Exception^ ex) {
			// Handle any errors
			MessageBox::Show("An error occurred: " + ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
		finally {
			// Close the connection
			if (sqlConn->State == ConnectionState::Open) {
				sqlConn->Close();
			}
		}
	}


	private: System::Void btn_EditInfo_Click(System::Object^ sender, System::EventArgs^ e) {


		// Connection string to the MySQL database
		sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";

		try {
			// Open the connection
			sqlConn->Open();

			// Retrieve input values
			String^ firstName = AdminStuFirstName->Text;
			String^ lastName = StuLastName->Text;
			String^ dob = AdminStudentDob->Value.ToString("yyyy-MM-dd");
			String^ major = AdminAddMajor->Text;
			String^ email = StuEmail->Text;
			String^ password = textBox1->Text; // Assuming textBox1 is for the password


			if (String::IsNullOrEmpty(firstName) || String::IsNullOrEmpty(lastName) ||
				String::IsNullOrEmpty(email) || String::IsNullOrEmpty(password) || String::IsNullOrEmpty(major)) {
				MessageBox::Show("Please fill in all required fields.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
				return;
			}

			// Check if student already exists (by email or student_id)
			sqlCmd->Connection = sqlConn;
			sqlCmd->CommandText = "SELECT user_id, first_name, last_name, email, password, dob, major FROM users INNER JOIN students ON users.user_id = students.student_id WHERE email = @Email";
			sqlCmd->Parameters->Clear();
			sqlCmd->Parameters->AddWithValue("@Email", email);

			MySqlDataReader^ reader = sqlCmd->ExecuteReader();

			if (reader->Read()) {
				// If student exists, fetch current details
				String^ oldFirstName = reader->GetString("first_name");
				String^ oldLastName = reader->GetString("last_name");
				String^ oldDob = reader->GetString("dob");
				String^ oldMajor = reader->GetString("major");
				String^ oldPassword = reader->GetString("password");

				// Display current details to the user
				MessageBox::Show("Existing Student Details:\n\n" +
					"First Name: " + oldFirstName + "\n" +
					"Last Name: " + oldLastName + "\n" +
					"Date of Birth: " + oldDob + "\n" +
					"Major: " + oldMajor + "\n" +
					"Password: " + oldPassword, "Existing Student Details", MessageBoxButtons::OK, MessageBoxIcon::Information);

				// Close reader after displaying previous details
				reader->Close();

				// Update student and user details
				String^ updateUserQuery = "UPDATE users SET first_name = @FirstName, last_name = @LastName, email = @Email, password = @Password WHERE email = @Email";
				sqlCmd->CommandText = updateUserQuery;
				sqlCmd->Parameters->Clear();
				sqlCmd->Parameters->AddWithValue("@FirstName", firstName);
				sqlCmd->Parameters->AddWithValue("@LastName", lastName);
				sqlCmd->Parameters->AddWithValue("@Email", email);
				sqlCmd->Parameters->AddWithValue("@Password", password);
				sqlCmd->ExecuteNonQuery();

				// Get user ID for the update to the students table
				sqlCmd->CommandText = "SELECT user_id FROM users WHERE email = @Email";
				int userId = Convert::ToInt32(sqlCmd->ExecuteScalar());

				// Update student details
				String^ updateStudentQuery = "UPDATE students SET dob = @Dob, major = @Major WHERE student_id = @UserId";
				sqlCmd->CommandText = updateStudentQuery;
				sqlCmd->Parameters->Clear();
				sqlCmd->Parameters->AddWithValue("@UserId", userId);
				sqlCmd->Parameters->AddWithValue("@Dob", dob);
				sqlCmd->Parameters->AddWithValue("@Major", major);
				sqlCmd->ExecuteNonQuery();

				// Notify the admin about the update
				MessageBox::Show("Student details updated successfully!", "Success", MessageBoxButtons::OK, MessageBoxIcon::Information);
			}
			else {


				// Insert into users table
				String^ insertUserQuery = "INSERT INTO users (first_name, last_name, email, password, role) VALUES (@FirstName, @LastName, @Email, @Password, 'student')";
				sqlCmd->CommandText = insertUserQuery;
				sqlCmd->Parameters->Clear();
				sqlCmd->Parameters->AddWithValue("@FirstName", firstName);
				sqlCmd->Parameters->AddWithValue("@LastName", lastName);
				sqlCmd->Parameters->AddWithValue("@Email", email);
				sqlCmd->Parameters->AddWithValue("@Password", password);
				sqlCmd->ExecuteNonQuery();

				// Get the user ID for the newly inserted user
				sqlCmd->CommandText = "SELECT LAST_INSERT_ID()";
				int userId = Convert::ToInt32(sqlCmd->ExecuteScalar());

				// Insert into students table
				String^ insertStudentQuery = "INSERT INTO students (student_id, dob, major) VALUES (@UserId, @Dob, @Major)";
				sqlCmd->CommandText = insertStudentQuery;
				sqlCmd->Parameters->Clear();
				sqlCmd->Parameters->AddWithValue("@UserId", userId);
				sqlCmd->Parameters->AddWithValue("@Dob", dob);
				sqlCmd->Parameters->AddWithValue("@Major", major);
				sqlCmd->ExecuteNonQuery();

				// Notify the admin
				MessageBox::Show("New student added successfully!", "Success", MessageBoxButtons::OK, MessageBoxIcon::Information);
			}
		}
		catch (Exception^ ex) {
			// Handle any errors
			MessageBox::Show("An error occurred: " + ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
		finally {
			// Close the connection
			if (sqlConn->State == ConnectionState::Open) {
				sqlConn->Close();
			}
		}

	}
private: System::Void btn_DeleteStudents_Click(System::Object^ sender, System::EventArgs^ e) {

	// Connection string to the MySQL database
	sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";
	try {
		sqlConn->Open();

		String^ studentEmail = StuEmail->Text;

		if (String::IsNullOrEmpty(studentEmail)) {
			MessageBox::Show("Please enter a valid student email.");
			return;
		}

		String^ query = "DELETE FROM Students WHERE email = @StudentEmail";

		sqlCmd->CommandText = query;
		sqlCmd->CommandType = CommandType::Text;

		sqlCmd->Parameters->Clear();
		sqlCmd->Parameters->AddWithValue("@StudentEmail", studentEmail);

		int rowsAffected = sqlCmd->ExecuteNonQuery();

		if (rowsAffected > 0) {
			MessageBox::Show("Student deleted successfully.");
		}
		else {
			MessageBox::Show("No student found with the provided email.");
		}
	}
	catch (Exception^ ex) {
		MessageBox::Show("Error: " + ex->Message);
	}
	finally {
		if (sqlConn->State == ConnectionState::Open) {
			sqlConn->Close();
		}
	}


}
};
}



