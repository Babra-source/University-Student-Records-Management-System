#pragma once
#include "MDI.h"
#include "StudentMDI.h"
#include "FacultyMDI.h"
#include "AdminMDI.h"
#include "passwordReset.h"

namespace UniversityApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	public ref class Login : public System::Windows::Forms::Form
	{
		MySqlConnection^ sqlConn = gcnew MySqlConnection();
		MySqlCommand^ sqlCmd = gcnew MySqlCommand();
		DataTable^ sqlDt = gcnew DataTable();
		MySqlDataAdapter^ sqlDtA = gcnew MySqlDataAdapter();
	public:
		MySqlDataReader^ sqlRd;

		Login(void)
		{
			InitializeComponent();
		}

	protected:
		~Login()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ Emaillabel;
	protected:
	private: System::Windows::Forms::TextBox^ EmailInput;
	private: System::Windows::Forms::Label^ Passwordlabel;

	private: System::Windows::Forms::TextBox^ LoginPassword;
	private: System::Windows::Forms::Button^ BtnSubmit;
	private: System::Windows::Forms::Button^ btnCancel;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::LinkLabel^ LinkResetPassword;
	private: System::Windows::Forms::LinkLabel^ LinkForgotPassword; // Added the forgot password link


	protected:

	private:
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Login::typeid));
			this->Emaillabel = (gcnew System::Windows::Forms::Label());
			this->EmailInput = (gcnew System::Windows::Forms::TextBox());
			this->Passwordlabel = (gcnew System::Windows::Forms::Label());
			this->LoginPassword = (gcnew System::Windows::Forms::TextBox());
			this->BtnSubmit = (gcnew System::Windows::Forms::Button());
			this->btnCancel = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->LinkResetPassword = (gcnew System::Windows::Forms::LinkLabel());
			this->LinkForgotPassword = (gcnew System::Windows::Forms::LinkLabel()); // Initializing forgot password link
			// Set the background image for the form
			this->BackgroundImage = System::Drawing::Image::FromFile("C:\\Users\\user\\Downloads\\school.jpg");  // Replace with your image file path
			this->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Stretch;  // Adjust how the image is displayed (Stretch, Tile, Zoom, etc.)

			this->SuspendLayout();
			// 
			// Emaillabel
			// 
			resources->ApplyResources(this->Emaillabel, L"Emaillabel");
			this->Emaillabel->BackColor = System::Drawing::Color::Transparent;
			this->Emaillabel->Name = L"Emaillabel";
			// 
			// EmailInput
			// 
			resources->ApplyResources(this->EmailInput, L"EmailInput");
			this->EmailInput->Name = L"EmailInput";
			this->EmailInput->TextChanged += gcnew System::EventHandler(this, &Login::EmailInput_TextChanged);
			// 
			// Passwordlabel
			// 
			resources->ApplyResources(this->Passwordlabel, L"Passwordlabel");
			this->Passwordlabel->BackColor = System::Drawing::Color::Transparent;
			this->Passwordlabel->Name = L"Passwordlabel";
			// 
			// LoginPassword
			// 
			resources->ApplyResources(this->LoginPassword, L"LoginPassword");
			this->LoginPassword->Name = L"LoginPassword";
			this->LoginPassword->PasswordChar = '*';  // This makes the password appear as dots
			// 
			// BtnSubmit
			// 
			resources->ApplyResources(this->BtnSubmit, L"BtnSubmit");
			this->BtnSubmit->Name = L"BtnSubmit";
			this->BtnSubmit->UseVisualStyleBackColor = true;
			this->BtnSubmit->Click += gcnew System::EventHandler(this, &Login::BtnSubmit_Click);
			// 
			// btnCancel
			// 
			resources->ApplyResources(this->btnCancel, L"btnCancel");
			this->btnCancel->Name = L"btnCancel";
			this->btnCancel->UseVisualStyleBackColor = true;
			this->btnCancel->Click += gcnew System::EventHandler(this, &Login::btnCancel_Click);
			// 
			// label1
			// 
			resources->ApplyResources(this->label1, L"label1");
			this->label1->BackColor = System::Drawing::Color::Transparent;
			this->label1->Name = L"label1";
			// 
			// LinkResetPassword
			// 
			resources->ApplyResources(this->LinkResetPassword, L"LinkResetPassword");
			this->LinkResetPassword->BackColor = System::Drawing::Color::Transparent;
			this->LinkResetPassword->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->LinkResetPassword->Name = L"LinkResetPassword";
			this->LinkResetPassword->TabStop = true;
			this->LinkResetPassword->LinkClicked += gcnew System::Windows::Forms::LinkLabelLinkClickedEventHandler(this, &Login::LinkResetPassword_LinkClicked);
			// 
			// LinkForgotPassword
			// 
			resources->ApplyResources(this->LinkForgotPassword, L"LinkForgotPassword");
			this->LinkForgotPassword->BackColor = System::Drawing::Color::Transparent;
			this->LinkForgotPassword->ForeColor = System::Drawing::SystemColors::ControlLightLight;
			this->LinkForgotPassword->Name = L"LinkForgotPassword";
			this->LinkForgotPassword->TabStop = true;
			this->LinkForgotPassword->LinkClicked += gcnew System::Windows::Forms::LinkLabelLinkClickedEventHandler(this, &Login::LinkForgotPassword_LinkClicked);
			// 
			// Login
			// 
			resources->ApplyResources(this, L"$this");
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::Gainsboro;
			this->Controls->Add(this->LinkForgotPassword); // Add the forgot password link first
			this->Controls->Add(this->LinkResetPassword);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btnCancel);
			this->Controls->Add(this->BtnSubmit);
			this->Controls->Add(this->LoginPassword);
			this->Controls->Add(this->Passwordlabel);
			this->Controls->Add(this->EmailInput);
			this->Controls->Add(this->Emaillabel);
			this->Name = L"Login";
			this->Load += gcnew System::EventHandler(this, &Login::Login_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	private: System::Void BtnSubmit_Click(System::Object^ sender, System::EventArgs^ e) {
		try {
			sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";

			String^ query = "SELECT role FROM users WHERE email = @Email AND password = @Password";
			sqlCmd = gcnew MySqlCommand(query, sqlConn);
			sqlCmd->Parameters->AddWithValue("@Email", EmailInput->Text);
			sqlCmd->Parameters->AddWithValue("@Password", LoginPassword->Text);
			sqlConn->Open();

			MySqlDataReader^ reader = sqlCmd->ExecuteReader();

			if (reader->Read()) {
				String^ role = reader["role"]->ToString();
				if (role == "admin") {
					MessageBox::Show("Welcome, Admin!");
					AdminMDI^ Admin = gcnew AdminMDI();
					Admin->Show();
					this->Hide();
				}
				else if (role == "student") {
					MessageBox::Show("Welcome, Student!");
					StudentMDI^ studentmdi = gcnew StudentMDI();
					studentmdi->Show();
					this->Hide();
				}
				else if (role == "faculty") {
					MessageBox::Show("Welcome, Faculty!");
					FacultyMDI^ facultyForm = gcnew FacultyMDI();
					facultyForm->Show();
					this->Hide();
				}
				else {
					MessageBox::Show("Unknown role detected.");
				}
			}
			else {
				MessageBox::Show("Invalid email or password.");
			}
			reader->Close();
		}
		catch (Exception^ ex) {
			MessageBox::Show("Error: " + ex->Message);
		}
		finally {
			sqlConn->Close();
		}
	}

	private: System::Void LinkResetPassword_LinkClicked(System::Object^ sender, System::Windows::Forms::LinkLabelLinkClickedEventArgs^ e) {
		passwordReset^ reset = gcnew passwordReset();
		reset->Show();
	}

	private: System::Void LinkForgotPassword_LinkClicked(System::Object^ sender, System::Windows::Forms::LinkLabelLinkClickedEventArgs^ e) {
		MessageBox::Show("Forgot password clicked");
	}

	private: System::Void btnCancel_Click(System::Object^ sender, System::EventArgs^ e) {
		Application::Exit();
	}

	private: System::Void Login_Load(System::Object^ sender, System::EventArgs^ e) {
		// Password field handling
	}
	private: System::Void EmailInput_TextChanged(System::Object^ sender, System::EventArgs^ e) {
		// Code to handle email input change, if any.
	}
	};
}
