#pragma once

namespace UniversityApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for CourseMaterials
	/// </summary>
	public ref class CourseMaterials : public System::Windows::Forms::Form
	{
		MySqlConnection^ sqlConn = gcnew MySqlConnection();
		MySqlCommand^ sqlCmd = gcnew MySqlCommand();
		DataTable^ sqlDt = gcnew DataTable();
		MySqlDataAdapter^ sqlDtA = gcnew MySqlDataAdapter();
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::TextBox^ textBoxCoursename;
	private: System::Windows::Forms::DataGridView^ materialsGridView2;
	private: System::Windows::Forms::Button^ btnUpdateCourseMaterials;

	public:
		MySqlDataReader^ sqlRd;
		CourseMaterials(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~CourseMaterials()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ labelCourseMaterialTitle;
	protected:
	private: System::Windows::Forms::TextBox^ TitleInput;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::TextBox^ textBox1Content;
	private: System::Windows::Forms::DateTimePicker^ UploadDate;
	private: System::Windows::Forms::Label^ labelUploadDate;
	private: System::Windows::Forms::Button^ btnUploadMaterial;
	private: System::Windows::Forms::Button^ btnViewmaterialUploaded;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(CourseMaterials::typeid));
			this->labelCourseMaterialTitle = (gcnew System::Windows::Forms::Label());
			this->TitleInput = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->textBox1Content = (gcnew System::Windows::Forms::TextBox());
			this->UploadDate = (gcnew System::Windows::Forms::DateTimePicker());
			this->labelUploadDate = (gcnew System::Windows::Forms::Label());
			this->btnUploadMaterial = (gcnew System::Windows::Forms::Button());
			this->btnViewmaterialUploaded = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->textBoxCoursename = (gcnew System::Windows::Forms::TextBox());
			this->materialsGridView2 = (gcnew System::Windows::Forms::DataGridView());
			this->btnUpdateCourseMaterials = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->materialsGridView2))->BeginInit();
			this->SuspendLayout();
			// 
			// labelCourseMaterialTitle
			// 
			this->labelCourseMaterialTitle->AutoSize = true;
			this->labelCourseMaterialTitle->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->labelCourseMaterialTitle->Location = System::Drawing::Point(63, 121);
			this->labelCourseMaterialTitle->Name = L"labelCourseMaterialTitle";
			this->labelCourseMaterialTitle->Size = System::Drawing::Size(43, 20);
			this->labelCourseMaterialTitle->TabIndex = 0;
			this->labelCourseMaterialTitle->Text = L"Title";
			// 
			// TitleInput
			// 
			this->TitleInput->Location = System::Drawing::Point(199, 121);
			this->TitleInput->Multiline = true;
			this->TitleInput->Name = L"TitleInput";
			this->TitleInput->Size = System::Drawing::Size(200, 31);
			this->TitleInput->TabIndex = 1;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(63, 177);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(78, 20);
			this->label1->TabIndex = 2;
			this->label1->Text = L"Content ";
			// 
			// textBox1Content
			// 
			this->textBox1Content->Location = System::Drawing::Point(199, 179);
			this->textBox1Content->Multiline = true;
			this->textBox1Content->Name = L"textBox1Content";
			this->textBox1Content->Size = System::Drawing::Size(200, 30);
			this->textBox1Content->TabIndex = 3;
			// 
			// UploadDate
			// 
			this->UploadDate->Location = System::Drawing::Point(199, 244);
			this->UploadDate->Name = L"UploadDate";
			this->UploadDate->Size = System::Drawing::Size(200, 20);
			this->UploadDate->TabIndex = 4;
			// 
			// labelUploadDate
			// 
			this->labelUploadDate->AutoSize = true;
			this->labelUploadDate->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->labelUploadDate->Location = System::Drawing::Point(63, 244);
			this->labelUploadDate->Name = L"labelUploadDate";
			this->labelUploadDate->Size = System::Drawing::Size(110, 20);
			this->labelUploadDate->TabIndex = 5;
			this->labelUploadDate->Text = L"Upload Date";
			// 
			// btnUploadMaterial
			// 
			this->btnUploadMaterial->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnUploadMaterial->Location = System::Drawing::Point(91, 310);
			this->btnUploadMaterial->Name = L"btnUploadMaterial";
			this->btnUploadMaterial->Size = System::Drawing::Size(104, 32);
			this->btnUploadMaterial->TabIndex = 6;
			this->btnUploadMaterial->Text = L"Upload Material";
			this->btnUploadMaterial->UseVisualStyleBackColor = true;
			this->btnUploadMaterial->Click += gcnew System::EventHandler(this, &CourseMaterials::btnUploadMaterial_Click);
			// 
			// btnViewmaterialUploaded
			// 
			this->btnViewmaterialUploaded->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btnViewmaterialUploaded->Location = System::Drawing::Point(447, 307);
			this->btnViewmaterialUploaded->Name = L"btnViewmaterialUploaded";
			this->btnViewmaterialUploaded->Size = System::Drawing::Size(109, 31);
			this->btnViewmaterialUploaded->TabIndex = 7;
			this->btnViewmaterialUploaded->Text = L"View material";
			this->btnViewmaterialUploaded->UseVisualStyleBackColor = true;
			this->btnViewmaterialUploaded->Click += gcnew System::EventHandler(this, &CourseMaterials::btnViewmaterialUploaded_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(63, 66);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(122, 20);
			this->label2->TabIndex = 8;
			this->label2->Text = L"Course Name ";
			// 
			// textBoxCoursename
			// 
			this->textBoxCoursename->Location = System::Drawing::Point(199, 68);
			this->textBoxCoursename->Multiline = true;
			this->textBoxCoursename->Name = L"textBoxCoursename";
			this->textBoxCoursename->Size = System::Drawing::Size(200, 29);
			this->textBoxCoursename->TabIndex = 9;
			// 
			// materialsGridView2
			// 
			this->materialsGridView2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->materialsGridView2->Location = System::Drawing::Point(118, 374);
			this->materialsGridView2->Name = L"materialsGridView2";
			this->materialsGridView2->Size = System::Drawing::Size(240, 150);
			this->materialsGridView2->TabIndex = 10;
			this->materialsGridView2->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &CourseMaterials::materialsGridView2_CellContentClick);
			// 
			// btnUpdateCourseMaterials
			// 
			this->btnUpdateCourseMaterials->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->btnUpdateCourseMaterials->Location = System::Drawing::Point(231, 307);
			this->btnUpdateCourseMaterials->Name = L"btnUpdateCourseMaterials";
			this->btnUpdateCourseMaterials->Size = System::Drawing::Size(168, 31);
			this->btnUpdateCourseMaterials->TabIndex = 11;
			this->btnUpdateCourseMaterials->Text = L"Update Course materials ";
			this->btnUpdateCourseMaterials->UseVisualStyleBackColor = true;
			this->btnUpdateCourseMaterials->Click += gcnew System::EventHandler(this, &CourseMaterials::btnUpdateCourseMaterials_Click);
			// 
			// CourseMaterials
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(715, 493);
			this->Controls->Add(this->btnUpdateCourseMaterials);
			this->Controls->Add(this->materialsGridView2);
			this->Controls->Add(this->textBoxCoursename);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->btnViewmaterialUploaded);
			this->Controls->Add(this->btnUploadMaterial);
			this->Controls->Add(this->labelUploadDate);
			this->Controls->Add(this->UploadDate);
			this->Controls->Add(this->textBox1Content);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->TitleInput);
			this->Controls->Add(this->labelCourseMaterialTitle);
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->Name = L"CourseMaterials";
			this->Text = L"CourseMaterials";
			this->Load += gcnew System::EventHandler(this, &CourseMaterials::CourseMaterials_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->materialsGridView2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}



	private: System::Void  LoadCourseMaterials() {
		try {

			// Set the connection string before opening the connection
			sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";

			// Open the connection
			sqlConn->Open();



			// Modify the SQL query to fetch course materials for the specified course name
			String^ CommandText = "SELECT c.course_name, m.title, m.content "
				"FROM course_materials m "
				"JOIN courses c ON m.course_id = c.course_id "
				"WHERE c.course_name = @CourseName"; // Use parameterized query to prevent SQL injection


			// Create the SQL command
			sqlCmd = gcnew MySqlCommand(CommandText, sqlConn);

			sqlCmd->Parameters->AddWithValue("@CourseName", textBoxCoursename);


			// Execute the query and get the data reader
			MySqlDataReader^ reader = sqlCmd->ExecuteReader();

			// Clear any existing rows in the DataGridView
			materialsGridView2->Rows->Clear();

			// Define columns if not already defined (add them programmatically)
			if (materialsGridView2->Columns->Count == 0) {

				// Add column for Course Name
				DataGridViewColumn^ column1 = gcnew DataGridViewTextBoxColumn();
				column1->Name = "CourseName";
				column1->HeaderText = "Course Name";
				materialsGridView2->Columns->Add(column1);

				// Add column for Material Title
				DataGridViewColumn^ column2 = gcnew DataGridViewTextBoxColumn();
				column2->Name = "Title";
				column2->HeaderText = "Material Title";
				materialsGridView2->Columns->Add(column2);

				// Add column for Material Content
				DataGridViewColumn^ column3 = gcnew DataGridViewTextBoxColumn();
				column3->Name = "Content";
				column3->HeaderText = "Material Content";
				materialsGridView2->Columns->Add(column3);
			}

			// Check if the reader contains any data
			if (reader->HasRows) {
				while (reader->Read()) {
					// Add data from the reader to the DataGridView
					materialsGridView2->Rows->Add(reader["course_name"], reader["title"], reader["content"]);
				}
			}
			else {
				MessageBox::Show("No course materials found for the selected course.", "No Data", MessageBoxButtons::OK, MessageBoxIcon::Information);
			}

			// Close the reader and connection after data is fetched
			reader->Close();
			sqlConn->Close();
		}
		catch (Exception^ ex) {
			// Show an error message if any exception occurs
			MessageBox::Show("Error: " + ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
	}
#pragma endregion
	private: System::Void btnUploadMaterial_Click(System::Object^ sender, System::EventArgs^ e) {

		try {
			// Validate inputs: ensure title and content are not empty
			if (String::IsNullOrWhiteSpace(TitleInput->Text) || String::IsNullOrWhiteSpace(textBox1Content->Text)) {
				MessageBox::Show("Please provide a valid title and content.", "Validation Error", MessageBoxButtons::OK, MessageBoxIcon::Warning);
				return;
			}

			if (sqlConn->State != ConnectionState::Closed) {
				sqlConn->Close();
			}
			// Open the database connection
			sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";
			
			sqlConn->Open();
			sqlCmd->Connection = sqlConn;
			

			// Retrieve the course_id based on the provided course name
			String^ queryGetCourseId = "SELECT course_id FROM courses WHERE course_name = @courseName";
			sqlCmd->CommandText = queryGetCourseId;

			// Clear any previous parameters
			sqlCmd->Parameters->Clear();
			sqlCmd->Parameters->AddWithValue("@courseName", textBoxCoursename->Text);  // Assuming courseNameInput is the TextBox for the course name

			// Execute the query and retrieve the course_id
			MySqlDataReader^ sqlRd = sqlCmd->ExecuteReader();

			// Check if a result was returned
			if (sqlRd->Read()) {
				// Get the course_id from the result
				String^ courseId = sqlRd->GetString("course_id");
				sqlRd->Close();  // Close the reader after retrieving the data

				// Now insert the material using the retrieved course_id
				String^ queryInsertMaterials = "INSERT INTO course_materials (course_id ,title, content) VALUES (@courseId, @Materialtitle, @ContentUpload)";
				sqlCmd->CommandText = queryInsertMaterials;

				// Clear any previous parameters
				sqlCmd->Parameters->Clear();

				// Add parameters for inserting the material
				sqlCmd->Parameters->AddWithValue("@courseId", courseId);  // Use the course_id retrieved from the previous query
				sqlCmd->Parameters->AddWithValue("@Materialtitle", TitleInput->Text);
				sqlCmd->Parameters->AddWithValue("@ContentUpload", textBox1Content->Text);

				MessageBox::Show("Topic: " + TitleInput);
				// Execute the insert query to add the material
				sqlCmd->ExecuteNonQuery();

				// Show success message
				MessageBox::Show("Material inserted successfully.", "Success", MessageBoxButtons::OK, MessageBoxIcon::Information);
			}
			else {
				// If no course found with the provided course name
				MessageBox::Show("Course not found.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
			}
		}
		catch (Exception^ ex) {
			// Catch any errors and display the error message
			MessageBox::Show("Error: " + ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
		finally {
			// Always close the database connection, whether an error occurred or not
			sqlConn->Close();
		}

	}






private: System::Void CourseMaterials_Load(System::Object^ sender, System::EventArgs^ e) {

	this->materialsGridView2->Visible = false;
}
private: System::Void materialsGridView2_CellContentClick(System::Object^ sender, System::Windows::Forms::DataGridViewCellEventArgs^ e) {


}
private: System::Void btnViewmaterialUploaded_Click(System::Object^ sender, System::EventArgs^ e) {
	this->materialsGridView2->Visible = true;
	LoadCourseMaterials();
}
private: System::Void btnUpdateCourseMaterials_Click(System::Object^ sender, System::EventArgs^ e) {

	String^ courseName = textBoxCoursename->Text;
	String^ newTitle = TitleInput->Text;
	String^ newContent = textBox1Content->Text;

	// Check if course name, title, or content is empty
	if (courseName->Length == 0 || newTitle->Length == 0 || newContent->Length == 0) {
		MessageBox::Show("Please ensure all fields (Course Name, Title, and Content) are filled.",
			"Input Error", MessageBoxButtons::OK, MessageBoxIcon::Warning);
		return;
	}

	Object^ courseId = nullptr; // Declare courseId at the appropriate scope

	try {
		// Establish connection
		sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";
		sqlConn->Open();

		// Fetch course_id based on course name
		String^ queryFetchCourseId = "SELECT course_id FROM Courses WHERE course_name = @CourseName";
		sqlCmd = gcnew MySqlCommand(queryFetchCourseId, sqlConn);
		sqlCmd->Parameters->AddWithValue("@CourseName", courseName);

		courseId = sqlCmd->ExecuteScalar(); // Fetch course ID
		if (courseId == nullptr) {
			MessageBox::Show("Course not found. Please check the course name.",
				"Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
			sqlConn->Close();
			return; // Exit if the course doesn't exist
		}

		// Proceed to update course materials
		String^ queryUpdateMaterials = "UPDATE Course_Materials "
			"SET title = @NewTitle, content = @NewContent "
			"WHERE course_id = @CourseId";

		sqlCmd = gcnew MySqlCommand(queryUpdateMaterials, sqlConn);
		sqlCmd->Parameters->AddWithValue("@CourseId", courseId);
		sqlCmd->Parameters->AddWithValue("@NewTitle", newTitle);
		sqlCmd->Parameters->AddWithValue("@NewContent", newContent);

		int rowsAffected = sqlCmd->ExecuteNonQuery(); // Execute the update query

		if (rowsAffected > 0) {
			MessageBox::Show("Course materials updated successfully!",
				"Success", MessageBoxButtons::OK, MessageBoxIcon::Information);
		}
		else {
			MessageBox::Show("No records were updated. Please ensure the course materials exist for the given course.",
				"Warning", MessageBoxButtons::OK, MessageBoxIcon::Warning);
		}
	}
	catch (Exception^ ex) {
		MessageBox::Show("Error: " + ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
	finally {
		sqlConn->Close(); // Ensure connection is closed
	}
}

};
}
