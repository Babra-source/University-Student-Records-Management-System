#pragma once
#include "VerifyStudents.h"

namespace UniversityApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for ManageFaculty
	/// </summary>
	public ref class ManageFaculty : public System::Windows::Forms::Form
	{
		MySqlConnection^ sqlConn = gcnew MySqlConnection();
		MySqlCommand^ sqlCmd = gcnew MySqlCommand();
		DataTable^ sqlDt = gcnew DataTable();
		MySqlDataAdapter^ sqlDtA = gcnew MySqlDataAdapter();
	private: System::Windows::Forms::ComboBox^ comboBoxDepartmentNames;

	public:


		MySqlDataReader^ sqlRd;
		ManageFaculty(void)
		{
			InitializeComponent();
			LoadDepartments();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~ManageFaculty()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	protected:
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ Password;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::TextBox^ FacultyFirstame;
	private: System::Windows::Forms::TextBox^ FacultyLastName;
	private: System::Windows::Forms::TextBox^ FacultyEmail;
	private: System::Windows::Forms::TextBox^ FacultyPassword;







	private: System::Windows::Forms::Button^ btn_AddFaculty;
	private: System::Windows::Forms::Button^ btn_EditFaculty;
	private: System::Windows::Forms::Button^ btn_DeleteFaculty;




	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->Password = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->FacultyFirstame = (gcnew System::Windows::Forms::TextBox());
			this->FacultyLastName = (gcnew System::Windows::Forms::TextBox());
			this->FacultyEmail = (gcnew System::Windows::Forms::TextBox());
			this->FacultyPassword = (gcnew System::Windows::Forms::TextBox());
			this->btn_AddFaculty = (gcnew System::Windows::Forms::Button());
			this->btn_EditFaculty = (gcnew System::Windows::Forms::Button());
			this->btn_DeleteFaculty = (gcnew System::Windows::Forms::Button());
			this->comboBoxDepartmentNames = (gcnew System::Windows::Forms::ComboBox());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(30, 39);
			this->label1->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(63, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"FirstName";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(30, 89);
			this->label2->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(63, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"LastName";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(30, 129);
			this->label3->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(37, 13);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Email";
			// 
			// Password
			// 
			this->Password->AutoSize = true;
			this->Password->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Password->Location = System::Drawing::Point(30, 159);
			this->Password->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->Password->Name = L"Password";
			this->Password->Size = System::Drawing::Size(61, 13);
			this->Password->TabIndex = 3;
			this->Password->Text = L"Password";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(30, 201);
			this->label4->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(112, 13);
			this->label4->TabIndex = 4;
			this->label4->Text = L"Department Name ";
			// 
			// FacultyFirstame
			// 
			this->FacultyFirstame->Location = System::Drawing::Point(181, 36);
			this->FacultyFirstame->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->FacultyFirstame->Name = L"FacultyFirstame";
			this->FacultyFirstame->Size = System::Drawing::Size(423, 20);
			this->FacultyFirstame->TabIndex = 5;
			// 
			// FacultyLastName
			// 
			this->FacultyLastName->Location = System::Drawing::Point(181, 82);
			this->FacultyLastName->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->FacultyLastName->Name = L"FacultyLastName";
			this->FacultyLastName->Size = System::Drawing::Size(423, 20);
			this->FacultyLastName->TabIndex = 6;
			// 
			// FacultyEmail
			// 
			this->FacultyEmail->Location = System::Drawing::Point(181, 121);
			this->FacultyEmail->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->FacultyEmail->Name = L"FacultyEmail";
			this->FacultyEmail->Size = System::Drawing::Size(423, 20);
			this->FacultyEmail->TabIndex = 7;
			// 
			// FacultyPassword
			// 
			this->FacultyPassword->Location = System::Drawing::Point(181, 151);
			this->FacultyPassword->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->FacultyPassword->Name = L"FacultyPassword";
			this->FacultyPassword->Size = System::Drawing::Size(423, 20);
			this->FacultyPassword->TabIndex = 8;
			// 
			// btn_AddFaculty
			// 
			this->btn_AddFaculty->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_AddFaculty->Location = System::Drawing::Point(34, 303);
			this->btn_AddFaculty->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btn_AddFaculty->Name = L"btn_AddFaculty";
			this->btn_AddFaculty->Size = System::Drawing::Size(119, 33);
			this->btn_AddFaculty->TabIndex = 10;
			this->btn_AddFaculty->Text = L"Add Faculty";
			this->btn_AddFaculty->UseVisualStyleBackColor = true;
			this->btn_AddFaculty->Click += gcnew System::EventHandler(this, &ManageFaculty::btn_AddFaculty_Click);
			// 
			// btn_EditFaculty
			// 
			this->btn_EditFaculty->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_EditFaculty->Location = System::Drawing::Point(200, 302);
			this->btn_EditFaculty->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btn_EditFaculty->Name = L"btn_EditFaculty";
			this->btn_EditFaculty->Size = System::Drawing::Size(132, 34);
			this->btn_EditFaculty->TabIndex = 11;
			this->btn_EditFaculty->Text = L"Edit Faculty";
			this->btn_EditFaculty->UseVisualStyleBackColor = true;
			this->btn_EditFaculty->Click += gcnew System::EventHandler(this, &ManageFaculty::btn_EditFaculty_Click);
			// 
			// btn_DeleteFaculty
			// 
			this->btn_DeleteFaculty->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_DeleteFaculty->Location = System::Drawing::Point(394, 302);
			this->btn_DeleteFaculty->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->btn_DeleteFaculty->Name = L"btn_DeleteFaculty";
			this->btn_DeleteFaculty->Size = System::Drawing::Size(128, 33);
			this->btn_DeleteFaculty->TabIndex = 12;
			this->btn_DeleteFaculty->Text = L"Delete Faculty";
			this->btn_DeleteFaculty->UseVisualStyleBackColor = true;
			this->btn_DeleteFaculty->Click += gcnew System::EventHandler(this, &ManageFaculty::btn_DeleteFaculty_Click);
			// 
			// comboBoxDepartmentNames
			// 
			this->comboBoxDepartmentNames->FormattingEnabled = true;
			this->comboBoxDepartmentNames->Location = System::Drawing::Point(181, 201);
			this->comboBoxDepartmentNames->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->comboBoxDepartmentNames->Name = L"comboBoxDepartmentNames";
			this->comboBoxDepartmentNames->Size = System::Drawing::Size(423, 21);
			this->comboBoxDepartmentNames->TabIndex = 13;
			// 
			// ManageFaculty
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(7, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(774, 432);
			this->Controls->Add(this->comboBoxDepartmentNames);
			this->Controls->Add(this->btn_DeleteFaculty);
			this->Controls->Add(this->btn_EditFaculty);
			this->Controls->Add(this->btn_AddFaculty);
			this->Controls->Add(this->FacultyPassword);
			this->Controls->Add(this->FacultyEmail);
			this->Controls->Add(this->FacultyLastName);
			this->Controls->Add(this->FacultyFirstame);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->Password);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Margin = System::Windows::Forms::Padding(4, 3, 4, 3);
			this->Name = L"ManageFaculty";
			this->Text = L"ManageFaculty";
			this->Load += gcnew System::EventHandler(this, &ManageFaculty::ManageFaculty_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}



		private:void LoadDepartments() {
			try {
				sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";
				sqlConn->Open();

				String^ query = "SELECT department_name FROM department";
				MySqlCommand^ sqlCmd = gcnew MySqlCommand(query, sqlConn);

				sqlRd = sqlCmd->ExecuteReader();
				comboBoxDepartmentNames->Items->Clear();
				while (sqlRd->Read()) {
					comboBoxDepartmentNames->Items->Add(sqlRd->GetString(0));
				}
				sqlRd->Close();
				sqlConn->Close();
			}
			catch (Exception^ ex) {
				MessageBox::Show("Error loading departments: " + ex->Message);
			}
		};

#pragma endregion
#pragma endregion
private: System::Void btn_AddFaculty_Click(System::Object^ sender, System::EventArgs^ e) {
	// Connection string to the MySQL database
	sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";

	try {
		// Open the connection
		sqlConn->Open();

		// Get the values from the text fields
		String^ firstName = FacultyFirstame->Text;  // Corrected the typo here
		String^ lastName = FacultyLastName->Text;
		String^ email = FacultyEmail->Text;
		String^ password = FacultyPassword->Text;

		// Validate the input (optional)
		if (String::IsNullOrWhiteSpace(firstName) || String::IsNullOrWhiteSpace(lastName) ||
			String::IsNullOrWhiteSpace(email) || String::IsNullOrWhiteSpace(password))
		{
			MessageBox::Show("Please fill in all fields.", "Validation Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
			return;
		}

		// Insert into users table
		String^ insertUserQuery = "INSERT INTO users (first_name, last_name, email, password, role) VALUES (@FirstName, @LastName, @Email, @Password, 'faculty')";
		sqlCmd->Connection = sqlConn;
		sqlCmd->CommandText = insertUserQuery;
		sqlCmd->Parameters->Clear();
		sqlCmd->Parameters->AddWithValue("@FirstName", firstName);
		sqlCmd->Parameters->AddWithValue("@LastName", lastName);
		sqlCmd->Parameters->AddWithValue("@Email", email);
		sqlCmd->Parameters->AddWithValue("@Password", password);
		sqlCmd->ExecuteNonQuery();

		// Retrieve the user ID after insertion
		int userId;
		sqlCmd->CommandText = "SELECT LAST_INSERT_ID()";
		userId = Convert::ToInt32(sqlCmd->ExecuteScalar());

		// Retrieve the selected department name
		String^ selectedDepartment = comboBoxDepartmentNames->Text;
		if (String::IsNullOrEmpty(selectedDepartment)) {
			MessageBox::Show("Please select a department.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
			return;
		}

		// Retrieve the Department ID based on the selected department name
		String^ queryDeptId = "SELECT department_id FROM department WHERE department_name = @deptName;";
		sqlCmd->CommandText = queryDeptId;
		sqlCmd->Parameters->Clear();
		sqlCmd->Parameters->AddWithValue("@deptName", selectedDepartment);

		sqlRd = sqlCmd->ExecuteReader();

		if (!sqlRd->Read()) {
			MessageBox::Show("Department not found.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
			sqlRd->Close();
			return;
		}

		int departmentId = sqlRd->GetInt32("department_id");
		sqlRd->Close();

		// Insert faculty details into the faculty table
		String^ queryInsertFaculty = "INSERT INTO faculty (faculty_id, department_id, faculty_name) VALUES (@userID, @deptId, @firstname);";

		sqlCmd->CommandText = queryInsertFaculty;
		sqlCmd->Parameters->Clear();
		sqlCmd->Parameters->AddWithValue("@userID", userId);  // Added the userID parameter
		sqlCmd->Parameters->AddWithValue("@deptId", departmentId);
		sqlCmd->Parameters->AddWithValue("@firstname", firstName);  // Corrected the parameter to match the query

		int result = sqlCmd->ExecuteNonQuery();

		// Notify the admin
		MessageBox::Show("Faculty added successfully!", "Success", MessageBoxButtons::OK, MessageBoxIcon::Information);  // Corrected the message

	}
	catch (Exception^ ex) {
		// Handle any errors
		MessageBox::Show("An error occurred: " + ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
	finally {
		// Close the connection
		if (sqlConn->State == ConnectionState::Open) {
			sqlConn->Close();
		}
	}
}

	
private: System::Void ManageFaculty_Load(System::Object^ sender, System::EventArgs^ e) {
	LoadDepartments();
}
private: System::Void btn_EditFaculty_Click(System::Object^ sender, System::EventArgs^ e) {
	// Step 1: Get the faculty details from the form fields
	String^ firstName = FacultyFirstame->Text;
	String^ lastName = FacultyLastName->Text;
	String^ email = FacultyEmail->Text;
	String^ password = FacultyPassword->Text;
	String^ departmentName = comboBoxDepartmentNames->SelectedItem->ToString();

	// Step 2: Validate that all fields are filled in
	if (firstName->Length == 0 || lastName->Length == 0 || email->Length == 0 || password->Length == 0 || departmentName->Length == 0)
	{
		MessageBox::Show("Please fill in all fields", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		return;
	}

	try
	{
		sqlConn->Open();

		// Step 3: Update user information in the 'users' table
		String^ updateUserQuery = "UPDATE users SET first_name = @FirstName, last_name = @LastName, password = @Password, role = 'faculty' WHERE email = @Email";
		sqlCmd->Connection = sqlConn;
		sqlCmd->CommandText = updateUserQuery;
		sqlCmd->Parameters->Clear();
		sqlCmd->Parameters->AddWithValue("@FirstName", firstName);
		sqlCmd->Parameters->AddWithValue("@LastName", lastName);
		sqlCmd->Parameters->AddWithValue("@Email", email);  // This assumes the email uniquely identifies the user
		sqlCmd->Parameters->AddWithValue("@Password", password);
		sqlCmd->ExecuteNonQuery();



		// Retrieve the user ID after insertion
		int userId;
		sqlCmd->CommandText = "SELECT LAST_INSERT_ID()";
		userId = Convert::ToInt32(sqlCmd->ExecuteScalar());

		// Step 4: Get the department ID based on the selected department name
		String^ queryDeptId = "SELECT department_id FROM department WHERE department_name = @deptName";
		sqlCmd->CommandText = queryDeptId;
		sqlCmd->Parameters->Clear();
		sqlCmd->Parameters->AddWithValue("@deptName", departmentName);

		sqlRd = sqlCmd->ExecuteReader();
		if (!sqlRd->Read()) {
			MessageBox::Show("Department not found.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
			sqlRd->Close();
			return;
		}

		int departmentId = sqlRd->GetInt32("department_id");
		sqlRd->Close();

		// Step 5: Update the faculty details in the 'faculty' table
		String^ updateFacultyQuery = "UPDATE faculty SET department_id = @deptId, faculty_name = @facultyName WHERE faculty_id = @userID";
		sqlCmd->CommandText = updateFacultyQuery;
		sqlCmd->Parameters->Clear();
		sqlCmd->Parameters->AddWithValue("@deptId", departmentId);
		sqlCmd->Parameters->AddWithValue("@facultyName", firstName); // Assuming faculty name is updated with the first name
		sqlCmd->Parameters->AddWithValue("@userID", userId); // You need to set `userId` correctly (either fetched or passed in)

		sqlCmd->ExecuteNonQuery();

		MessageBox::Show("Faculty details updated successfully.", "Success", MessageBoxButtons::OK, MessageBoxIcon::Information);
	}
	catch (Exception^ ex)
	{
		// Handle any exceptions that occur
		MessageBox::Show("Error: " + ex->Message, "Database Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
	finally
	{
		// Close the database connection
		if (sqlConn->State == ConnectionState::Open)
		{
			sqlConn->Close();
		}
	}
}


private: System::Void btn_DeleteFaculty_Click(System::Object^ sender, System::EventArgs^ e) {
	
	sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";

	try {
		sqlConn->Open();
		sqlCmd->Connection = sqlConn;

		// Step 1: Get the faculty email from the form
		String^ facultyEmail = FacultyEmail->Text;

		if (String::IsNullOrEmpty(facultyEmail)) {
			MessageBox::Show("Please enter a valid faculty email.");
			return;
		}

		// Step 2: Retrieve the user_id from the 'users' table based on the email
		String^ queryGetUserId = "SELECT user_id FROM users WHERE email = @FacultyEmail";
		sqlCmd->CommandText = queryGetUserId;
		sqlCmd->Parameters->Clear();
		sqlCmd->Parameters->AddWithValue("@FacultyEmail", facultyEmail);

		sqlRd = sqlCmd->ExecuteReader();

		if (!sqlRd->Read()) {
			MessageBox::Show("No faculty found with the provided email.");
			sqlRd->Close();
			return;
		}

		int userId = sqlRd->GetInt32("user_id");
		sqlRd->Close();

		// Step 3: Delete the faculty record from the 'faculty' table using the user_id
		String^ deleteFacultyQuery = "DELETE FROM faculty WHERE faculty_id = @UserId";
		sqlCmd->CommandText = deleteFacultyQuery;
		sqlCmd->Parameters->Clear();
		sqlCmd->Parameters->AddWithValue("@UserId", userId);

		int facultyRowsAffected = sqlCmd->ExecuteNonQuery();

		if (facultyRowsAffected == 0) {
			MessageBox::Show("No faculty record found to delete.");
			return;
		}

		// Step 4: Delete the corresponding user record from the 'users' table
		String^ deleteUserQuery = "DELETE FROM users WHERE user_id = @UserId";
		sqlCmd->CommandText = deleteUserQuery;
		sqlCmd->Parameters->Clear();
		sqlCmd->Parameters->AddWithValue("@UserId", userId);

		int userRowsAffected = sqlCmd->ExecuteNonQuery();

		if (userRowsAffected > 0) {
			MessageBox::Show("Faculty deleted successfully.");
		}
		else {
			MessageBox::Show("No user found with the provided email.");
		}
	}
	catch (Exception^ ex) {
		// Handle any exceptions that occur
		MessageBox::Show("Error: " + ex->Message);
	}
	finally {
		// Close the database connection
		if (sqlConn->State == ConnectionState::Open) {
			sqlConn->Close();
		}
	}
}


};
}
