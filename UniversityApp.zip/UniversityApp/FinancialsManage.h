#pragma once

namespace UniversityApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for FinancialsManage
	/// </summary>
	public ref class FinancialsManage : public System::Windows::Forms::Form
	{
		MySqlConnection^ sqlConn = gcnew MySqlConnection();
		MySqlCommand^ sqlCmd = gcnew MySqlCommand();
		DataTable^ sqlDt = gcnew DataTable();
		MySqlDataAdapter^ sqlDtA = gcnew MySqlDataAdapter();
	public:

		MySqlDataReader^ sqlRd;
		FinancialsManage(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~FinancialsManage()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	protected:
	private: System::Windows::Forms::TextBox^ FinanceStuId;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Button^ buttonApply;
	private: System::Windows::Forms::ComboBox^ comboBox1;
	private: System::Windows::Forms::DataGridView^ dataGridView1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(FinancialsManage::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->FinanceStuId = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->buttonApply = (gcnew System::Windows::Forms::Button());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(41, 41);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(70, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"StudentsID";
			// 
			// FinanceStuId
			// 
			this->FinanceStuId->Location = System::Drawing::Point(163, 38);
			this->FinanceStuId->Name = L"FinanceStuId";
			this->FinanceStuId->Size = System::Drawing::Size(178, 20);
			this->FinanceStuId->TabIndex = 1;
			this->FinanceStuId->TextChanged += gcnew System::EventHandler(this, &FinancialsManage::FinanceStuId_TextChanged);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(41, 107);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(43, 13);
			this->label2->TabIndex = 2;
			this->label2->Text = L"Status";
			// 
			// buttonApply
			// 
			this->buttonApply->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->buttonApply->Location = System::Drawing::Point(199, 160);
			this->buttonApply->Name = L"buttonApply";
			this->buttonApply->Size = System::Drawing::Size(75, 23);
			this->buttonApply->TabIndex = 4;
			this->buttonApply->Text = L"Apply";
			this->buttonApply->UseVisualStyleBackColor = true;
			this->buttonApply->Click += gcnew System::EventHandler(this, &FinancialsManage::buttonApply_Click);
			// 
			// comboBox1
			// 
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"Approved", L"Rejected" });
			this->comboBox1->Location = System::Drawing::Point(163, 99);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(187, 21);
			this->comboBox1->TabIndex = 5;
			// 
			// dataGridView1
			// 
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Location = System::Drawing::Point(100, 213);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->Size = System::Drawing::Size(307, 150);
			this->dataGridView1->TabIndex = 6;
			this->dataGridView1->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &FinancialsManage::dataGridView1_CellContentClick);
			// 
			// FinancialsManage
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(522, 401);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->buttonApply);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->FinanceStuId);
			this->Controls->Add(this->label1);
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->Name = L"FinancialsManage";
			this->Text = L"FinancialsManage";
			this->Load += gcnew System::EventHandler(this, &FinancialsManage::FinancialsManage_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}


	private: void LoadpaymentData() {
		// Connection string (modify as per your database settings)
		MySqlConnection^ sqlConn = gcnew MySqlConnection("datasource=localhost;port=3306;username=root;password=;database=university_management_system");
		String^ query = "SELECT student_id, payment_amount, status FROM payments";

		try {
			// Open the database connection
			sqlConn->Open();

			// Initialize SQL Command
			MySqlCommand^ sqlCmd = gcnew MySqlCommand(query, sqlConn);

			// Set up the adapter to execute the query and fill the DataTable
			MySqlDataAdapter^ adapter = gcnew MySqlDataAdapter(sqlCmd);
			DataTable^ dt = gcnew DataTable();
			adapter->Fill(dt); // Execute query and store results in DataTable

			// Bind DataTable to DataGridView
			dataGridView1->DataSource = dt;
		}
		catch (Exception^ ex) {
			MessageBox::Show("Error loading student data: " + ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
	}

#pragma endregion
	private: System::Void FinanceStuId_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void FinancialsManage_Load(System::Object^ sender, System::EventArgs^ e) {
	LoadpaymentData();
}
private: System::Void buttonApply_Click(System::Object^ sender, System::EventArgs^ e) {

	// Connection string (modify as per your database settings)
	MySqlConnection^ sqlConn = gcnew MySqlConnection("datasource=localhost;port=3306;username=root;password=;database=university_management_system");

	// Retrieve student ID and payment status
	String^ studentID = FinanceStuId->Text; // TextBox for student ID
	String^ selectedStatus = comboBox1->Text; // ComboBox for payment status
	

	// Validate input
	if (String::IsNullOrEmpty(studentID) || String::IsNullOrEmpty(selectedStatus)) {
		MessageBox::Show("Please provide Student ID, Status, and Amount Paid.", "Validation Error", MessageBoxButtons::OK, MessageBoxIcon::Warning);
		return;
	}



	// Query to update the payment details
	String^ updateQuery = "UPDATE payments SET status = @status WHERE student_id = @studentID";

	try {
		// Open the database connection
		sqlConn->Open();

		// Prepare the update command
		MySqlCommand^ updateCmd = gcnew MySqlCommand(updateQuery, sqlConn);
		updateCmd->Parameters->AddWithValue("@status", selectedStatus);
		updateCmd->Parameters->AddWithValue("@studentID", studentID);

		int rowsAffected = updateCmd->ExecuteNonQuery();

		// Check if the update was successful
		if (rowsAffected > 0) {
			MessageBox::Show("Payment details updated successfully.", "Success", MessageBoxButtons::OK, MessageBoxIcon::Information);

			// Reload data in DataGridView to reflect the changes
			LoadpaymentData();
		}
		else {
			MessageBox::Show("No matching student found with the provided ID.", "Update Failed", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
	}
	catch (Exception^ ex) {
		MessageBox::Show("Error updating payment details: " + ex->Message, "Database Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
	finally {
		// Ensure the connection is closed
		if (sqlConn->State == ConnectionState::Open) {
			sqlConn->Close();
		}
	}
}
private: System::Void dataGridView1_CellContentClick(System::Object^ sender, System::Windows::Forms::DataGridViewCellEventArgs^ e) {
}
};
}
