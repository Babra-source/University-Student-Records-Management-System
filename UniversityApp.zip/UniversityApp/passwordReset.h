#pragma once
#include "MDI.h"

namespace UniversityApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for passwordReset
	/// </summary>
	public ref class passwordReset : public System::Windows::Forms::Form
	{
		MySqlConnection^ sqlConn = gcnew MySqlConnection();
		MySqlCommand^ sqlCmd = gcnew MySqlCommand();
		DataTable^ sqlDt = gcnew DataTable();
		MySqlDataAdapter^ sqlDtA = gcnew MySqlDataAdapter();


	public:
		MySqlDataReader^ sqlRd;
		passwordReset(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~passwordReset()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ ResetEmail;
	private: System::Windows::Forms::TextBox^ InputReset;

	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::TextBox^ NewPassword;
	private: System::Windows::Forms::TextBox^ ConfirmPassword;
	private: System::Windows::Forms::Button^ Btn_Submit;

	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(passwordReset::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->ResetEmail = (gcnew System::Windows::Forms::Label());
			this->InputReset = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->NewPassword = (gcnew System::Windows::Forms::TextBox());
			this->ConfirmPassword = (gcnew System::Windows::Forms::TextBox());
			this->Btn_Submit = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(34, 29);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(212, 24);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Reset your Password ";
			this->label1->Click += gcnew System::EventHandler(this, &passwordReset::label1_Click);
			// 
			// ResetEmail
			// 
			this->ResetEmail->AutoSize = true;
			this->ResetEmail->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ResetEmail->Location = System::Drawing::Point(25, 86);
			this->ResetEmail->Name = L"ResetEmail";
			this->ResetEmail->Size = System::Drawing::Size(50, 18);
			this->ResetEmail->TabIndex = 1;
			this->ResetEmail->Text = L"Email";
			// 
			// InputReset
			// 
			this->InputReset->Location = System::Drawing::Point(178, 87);
			this->InputReset->Name = L"InputReset";
			this->InputReset->Size = System::Drawing::Size(221, 20);
			this->InputReset->TabIndex = 2;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(25, 148);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(126, 18);
			this->label2->TabIndex = 3;
			this->label2->Text = L"New Password ";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(25, 208);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(148, 18);
			this->label3->TabIndex = 4;
			this->label3->Text = L"Confirm Password";
			// 
			// NewPassword
			// 
			this->NewPassword->Location = System::Drawing::Point(178, 149);
			this->NewPassword->Name = L"NewPassword";
			this->NewPassword->Size = System::Drawing::Size(206, 20);
			this->NewPassword->TabIndex = 5;
			this->NewPassword->TextChanged += gcnew System::EventHandler(this, &passwordReset::NewPassword_TextChanged);
			// 
			// ConfirmPassword
			// 
			this->ConfirmPassword->Location = System::Drawing::Point(178, 209);
			this->ConfirmPassword->Name = L"ConfirmPassword";
			this->ConfirmPassword->Size = System::Drawing::Size(206, 20);
			this->ConfirmPassword->TabIndex = 6;
			this->ConfirmPassword->TextChanged += gcnew System::EventHandler(this, &passwordReset::textBox3_TextChanged);
			// 
			// Btn_Submit
			// 
			this->Btn_Submit->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Btn_Submit->Location = System::Drawing::Point(219, 276);
			this->Btn_Submit->Name = L"Btn_Submit";
			this->Btn_Submit->Size = System::Drawing::Size(103, 46);
			this->Btn_Submit->TabIndex = 7;
			this->Btn_Submit->Text = L"Submit ";
			this->Btn_Submit->UseVisualStyleBackColor = true;
			this->Btn_Submit->Click += gcnew System::EventHandler(this, &passwordReset::Btn_Submit_Click);
			// 
			// passwordReset
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(570, 402);
			this->Controls->Add(this->Btn_Submit);
			this->Controls->Add(this->ConfirmPassword);
			this->Controls->Add(this->NewPassword);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->InputReset);
			this->Controls->Add(this->ResetEmail);
			this->Controls->Add(this->label1);
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->Name = L"passwordReset";
			this->Text = L"passwordReset";
			this->Load += gcnew System::EventHandler(this, &passwordReset::passwordReset_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void textBox3_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void passwordReset_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void Btn_Submit_Click(System::Object^ sender, System::EventArgs^ e) {
		if (sqlConn->State != ConnectionState::Closed) {
    sqlConn->Close();
}

sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";

try {
    // Retrieve inputs
    String^ email = this->InputReset->Text->Trim();
    String^ password = this->NewPassword->Text;
    String^ confirmPassword = this->ConfirmPassword->Text;

    // Validation
    if (String::IsNullOrWhiteSpace(email)) {
        MessageBox::Show("Please enter your email address.", "Warning", MessageBoxButtons::OK, MessageBoxIcon::Warning);
        return;
    }

    if (password != confirmPassword) {
        MessageBox::Show("Passwords do not match.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
        return;
    }

    if (password->Length < 8) {
        MessageBox::Show("Password must be at least 8 characters long.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
        return;
    }

    sqlConn->Open();
    sqlCmd->Connection = sqlConn;

    // Check if email exists
    sqlCmd->CommandText = "SELECT COUNT(*) FROM users WHERE Email = @Email";
    sqlCmd->Parameters->Clear();
    sqlCmd->Parameters->AddWithValue("@Email", email);

    int count = Convert::ToInt32(sqlCmd->ExecuteScalar());

    if (count > 0) {
        // Update password
        sqlCmd->CommandText = "UPDATE users SET Password = @Password WHERE Email = @Email";
        sqlCmd->Parameters->Clear();
        sqlCmd->Parameters->AddWithValue("@Password", password); // Plaintext password
        sqlCmd->Parameters->AddWithValue("@Email", email);

        int rowsAffected = sqlCmd->ExecuteNonQuery();

        if (rowsAffected > 0) {
            MessageBox::Show("Password reset successful.", "Success", MessageBoxButtons::OK, MessageBoxIcon::Information);
        } else {
            MessageBox::Show("Password reset failed.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
        }
    } else {
        MessageBox::Show("Email not found.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
    }
} catch (Exception^ ex) {
    MessageBox::Show("Error: " + ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
} finally {
    if (sqlConn->State == ConnectionState::Open) {
        sqlConn->Close();
    }
}

	};
	private: System::Void NewPassword_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	};

}