#pragma once

namespace UniversityApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;
	using namespace System::Windows::Forms;

	/// <summary>
	/// Summary for ManageCourses
	/// </summary>
	public ref class ManageCourses : public System::Windows::Forms::Form
	{
		MySqlConnection^ sqlConn = gcnew MySqlConnection();
		MySqlCommand^ sqlCmd = gcnew MySqlCommand();
		DataTable^ sqlDt = gcnew DataTable();
		MySqlDataAdapter^ sqlDtA = gcnew MySqlDataAdapter();
	public:
		MySqlDataReader^ sqlRd;
		ManageCourses(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~ManageCourses()
		{
			if (components)
			{
				delete components;
			}
		}

	protected:
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ FacultyID;

	private: System::Windows::Forms::TextBox^ CourseNameInput;
	private: System::Windows::Forms::ComboBox^ comboBoxSemester;




	private: System::Windows::Forms::TextBox^ textBox2;
	private: System::Windows::Forms::Button^ btnAddCourse;
	private: System::Windows::Forms::Button^ btnEditCourse;
	private: System::Windows::Forms::Button^ btnRemoveCourse;
	private: System::Windows::Forms::TextBox^ CreditInput;





	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->FacultyID = (gcnew System::Windows::Forms::Label());
			this->CourseNameInput = (gcnew System::Windows::Forms::TextBox());
			this->comboBoxSemester = (gcnew System::Windows::Forms::ComboBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->btnAddCourse = (gcnew System::Windows::Forms::Button());
			this->btnEditCourse = (gcnew System::Windows::Forms::Button());
			this->btnRemoveCourse = (gcnew System::Windows::Forms::Button());
			this->CreditInput = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(12, 53);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(117, 20);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Course Name";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(13, 112);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(66, 20);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Credits";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(12, 172);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(86, 20);
			this->label4->TabIndex = 3;
			this->label4->Text = L"Semester";
			// 
			// FacultyID
			// 
			this->FacultyID->AutoSize = true;
			this->FacultyID->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->FacultyID->Location = System::Drawing::Point(13, 227);
			this->FacultyID->Name = L"FacultyID";
			this->FacultyID->Size = System::Drawing::Size(91, 20);
			this->FacultyID->TabIndex = 4;
			this->FacultyID->Text = L"Faculty ID";
			// 
			// CourseNameInput
			// 
			this->CourseNameInput->Location = System::Drawing::Point(199, 55);
			this->CourseNameInput->Name = L"CourseNameInput";
			this->CourseNameInput->Size = System::Drawing::Size(201, 20);
			this->CourseNameInput->TabIndex = 8;
			// 
			// comboBoxSemester
			// 
			this->comboBoxSemester->FormattingEnabled = true;
			this->comboBoxSemester->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"1", L"2" });
			this->comboBoxSemester->Location = System::Drawing::Point(199, 174);
			this->comboBoxSemester->Name = L"comboBoxSemester";
			this->comboBoxSemester->Size = System::Drawing::Size(201, 21);
			this->comboBoxSemester->TabIndex = 9;
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(199, 229);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(201, 20);
			this->textBox2->TabIndex = 10;
			// 
			// btnAddCourse
			// 
			this->btnAddCourse->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnAddCourse->Location = System::Drawing::Point(17, 348);
			this->btnAddCourse->Name = L"btnAddCourse";
			this->btnAddCourse->Size = System::Drawing::Size(113, 35);
			this->btnAddCourse->TabIndex = 11;
			this->btnAddCourse->Text = L"Add Course";
			this->btnAddCourse->UseVisualStyleBackColor = true;
			this->btnAddCourse->Click += gcnew System::EventHandler(this, &ManageCourses::btnAddCourse_Click);
			// 
			// btnEditCourse
			// 
			this->btnEditCourse->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnEditCourse->Location = System::Drawing::Point(190, 348);
			this->btnEditCourse->Name = L"btnEditCourse";
			this->btnEditCourse->Size = System::Drawing::Size(113, 35);
			this->btnEditCourse->TabIndex = 12;
			this->btnEditCourse->Text = L"Edit Course";
			this->btnEditCourse->UseVisualStyleBackColor = true;
			this->btnEditCourse->Click += gcnew System::EventHandler(this, &ManageCourses::btnEditCourse_Click);
			// 
			// btnRemoveCourse
			// 
			this->btnRemoveCourse->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btnRemoveCourse->Location = System::Drawing::Point(356, 348);
			this->btnRemoveCourse->Name = L"btnRemoveCourse";
			this->btnRemoveCourse->Size = System::Drawing::Size(158, 35);
			this->btnRemoveCourse->TabIndex = 13;
			this->btnRemoveCourse->Text = L"Remove Course";
			this->btnRemoveCourse->UseVisualStyleBackColor = true;
			this->btnRemoveCourse->Click += gcnew System::EventHandler(this, &ManageCourses::btnRemoveCourse_Click);
			// 
			// CreditInput
			// 
			this->CreditInput->Location = System::Drawing::Point(199, 112);
			this->CreditInput->Name = L"CreditInput";
			this->CreditInput->Size = System::Drawing::Size(201, 20);
			this->CreditInput->TabIndex = 7;
			// 
			// ManageCourses
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(616, 455);
			this->Controls->Add(this->btnRemoveCourse);
			this->Controls->Add(this->btnEditCourse);
			this->Controls->Add(this->btnAddCourse);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->comboBoxSemester);
			this->Controls->Add(this->CourseNameInput);
			this->Controls->Add(this->CreditInput);
			this->Controls->Add(this->FacultyID);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Name = L"ManageCourses";
			this->Text = L"ManageCourses";
			this->Load += gcnew System::EventHandler(this, &ManageCourses::ManageCourses_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnAddCourse_Click(System::Object^ sender, System::EventArgs^ e)
	{
		try
		{
			// Connection string (modify as per your database settings)

			sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";

			// Get data from form inputs
			String^ courseName = CourseNameInput->Text;
			String^ credits = CreditInput->Text;
			String^ semester = comboBoxSemester->Text;
			String^ facultyID = textBox2->Text;

			// Validate input
			if (courseName == "" || credits == "" || semester == "" || facultyID == "")
			{
				MessageBox::Show("All fields are required.");
				return;
			}

			// Create SQL query to insert data
			String^ query = "INSERT INTO Courses (course_name, credits, semester, faculty_id) VALUES (@CourseName, @Credits, @Semester, @FacultyID)";

			// Open the database connection
			sqlConn->Open();

			// Create a command to execute the query
			MySqlCommand^ command = gcnew MySqlCommand(query, sqlConn);

			// Add parameters to the query
			command->Parameters->AddWithValue("@CourseName", courseName);
			command->Parameters->AddWithValue("@Credits", credits);
			command->Parameters->AddWithValue("@Semester", semester);
			command->Parameters->AddWithValue("@FacultyID", facultyID);

			// Execute the query
			int rowsAffected = command->ExecuteNonQuery();

			// Check if the insert was successful
			if (rowsAffected > 0)
			{
				MessageBox::Show("Course added successfully.");

				// Optionally, clear the inputs after adding
				CourseNameInput->Clear();
				CreditInput->Clear();
				comboBoxSemester->SelectedIndex = -1;
				textBox2->Clear();
			}
			else
			{
				MessageBox::Show("Failed to add the course.");
			}
		}
		catch (Exception^ ex)
		{
			MessageBox::Show("Error: " + ex->Message);
		}
	}

private: System::Void btnEditCourse_Click(System::Object^ sender, System::EventArgs^ e)
{
	try
	{
		// Connection string (modify as per your database settings)
		sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";

		// Get the course name from the input
		String^ courseName = CourseNameInput->Text;

		// Validate that course name is provided
		if (courseName == "")
		{
			MessageBox::Show("Please enter the course name.");
			return;
		}

		// Query to fetch the current course details
		String^ fetchQuery = "SELECT * FROM Courses WHERE course_name = @CourseName";

		// Open the database connection
		sqlConn->Open();

		// Create a command to fetch the course data
		MySqlCommand^ fetchCommand = gcnew MySqlCommand(fetchQuery, sqlConn);
		fetchCommand->Parameters->AddWithValue("@CourseName", courseName);

		MySqlDataReader^ reader = fetchCommand->ExecuteReader();

		if (reader->HasRows)
		{
			// Display the previous course details
			reader->Read(); // Read the first (and should be only) row
			String^ prevCredits = reader["credits"]->ToString();
			String^ prevSemester = reader["semester"]->ToString();
			String^ prevFacultyID = reader["faculty_id"]->ToString();

			// Show previous course details
			MessageBox::Show("Previous Course Details:\n" +
				"Credits: " + prevCredits + "\n" +
				"Semester: " + prevSemester + "\n" +
				"Faculty ID: " + prevFacultyID,
				"Previous Course Details");

			reader->Close(); // Close reader after fetching the data

			// Get the new data for updating the course
			String^ newCredits = CreditInput->Text;
			String^ newSemester = comboBoxSemester->Text;
			String^ newFacultyID = textBox2->Text;

			// Validate the new input data
			if (newCredits == "" || newSemester == "" || newFacultyID == "")
			{
				MessageBox::Show("All fields are required for the update.");
				return;
			}

			// Create SQL query to update the course data
			String^ updateQuery = "UPDATE Courses SET credits = @Credits, semester = @Semester, faculty_id = @FacultyID WHERE course_name = @CourseName";

			// Create a command to execute the update query
			MySqlCommand^ updateCommand = gcnew MySqlCommand(updateQuery, sqlConn);

			// Add parameters to the update query
			updateCommand->Parameters->AddWithValue("@Credits", newCredits);
			updateCommand->Parameters->AddWithValue("@Semester", newSemester);
			updateCommand->Parameters->AddWithValue("@FacultyID", newFacultyID);
			updateCommand->Parameters->AddWithValue("@CourseName", courseName);

			// Execute the update query
			int rowsAffected = updateCommand->ExecuteNonQuery();

			if (rowsAffected > 0)
			{
				// Show success message with updated details
				MessageBox::Show("Course updated successfully.\n" +
					"Updated Details:\n" +
					"Credits: " + newCredits + "\n" +
					"Semester: " + newSemester + "\n" +
					"Faculty ID: " + newFacultyID,
					"Course Updated");
			}
			else
			{
				MessageBox::Show("Failed to update the course.");
			}
		}
		else
		{
			MessageBox::Show("Course not found.");
		}
	}
	catch (Exception^ ex)
	{
		MessageBox::Show("Error: " + ex->Message);
	}
	finally
	{
		// Close the connection
		if (sqlConn->State == ConnectionState::Open)
		{
			sqlConn->Close();
		}
	}
}


private: System::Void btnRemoveCourse_Click(System::Object^ sender, System::EventArgs^ e) {
	try
	{
		// Connection string (modify as per your database settings)
		sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";

		// Get the course name from input
		String^ courseName = CourseNameInput->Text;

		// Validate that course name is provided
		if (courseName == "")
		{
			MessageBox::Show("Please enter the course name.");
			return;
		}

		// Query to fetch the current course details
		String^ fetchQuery = "SELECT * FROM Courses WHERE course_name = @CourseName";

		// Open the database connection
		sqlConn->Open();

		// Create a command to fetch the course data
		MySqlCommand^ fetchCommand = gcnew MySqlCommand(fetchQuery, sqlConn);
		fetchCommand->Parameters->AddWithValue("@CourseName", courseName);

		MySqlDataReader^ reader = fetchCommand->ExecuteReader();

		if (reader->HasRows)
		{
			// Display the previous course details
			reader->Read(); // Read the first (and should be only) row
			String^ prevCredits = reader["credits"]->ToString();
			String^ prevSemester = reader["semester"]->ToString();
			String^ prevFacultyID = reader["faculty_id"]->ToString();

			// Show previous course details in a message box
			MessageBox::Show("Course Details:\n" +
				"Course Name: " + courseName + "\n" +
				"Credits: " + prevCredits + "\n" +
				"Semester: " + prevSemester + "\n" +
				"Faculty ID: " + prevFacultyID,
				"Course Details");

			reader->Close(); // Close reader after fetching the data

			// Query to delete the course
			String^ deleteQuery = "DELETE FROM Courses WHERE course_name = @CourseName";
			MySqlCommand^ deleteCommand = gcnew MySqlCommand(deleteQuery, sqlConn);
			deleteCommand->Parameters->AddWithValue("@CourseName", courseName);

			// Execute the delete query
			int rowsAffected = deleteCommand->ExecuteNonQuery();

			if (rowsAffected > 0)
			{
				// Show success message
				MessageBox::Show("Course deleted successfully.", "Success", MessageBoxButtons::OK, MessageBoxIcon::Information);
			}
			else
			{
				MessageBox::Show("Failed to delete the course.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
			}
		}
		else
		{
			MessageBox::Show("Course not found.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
	}
	catch (Exception^ ex)
	{
		MessageBox::Show("Error: " + ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
	finally
	{
		// Close the connection
		if (sqlConn->State == ConnectionState::Open)
		{
			sqlConn->Close();
		}
	}
}
private: System::Void ManageCourses_Load(System::Object^ sender, System::EventArgs^ e) {
}
};
}


