#include "Login.h"

using namespace System;
using namespace System::Windows::Forms;

int main(array<String^>^ arg)
{
    Application::EnableVisualStyles();
    Application::SetCompatibleTextRenderingDefault(false);
    UniversityApp::Login form;
    Application::Run(% form);
};