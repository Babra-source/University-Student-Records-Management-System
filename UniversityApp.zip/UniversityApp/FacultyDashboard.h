#pragma once
#include "GradeEntry.h"
#include "Coursematerials.h"
#include "VerifyStudents.h"
#include "FacultyProfile.h"


namespace UniversityApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for FacultyDashboard
	/// </summary>
	public ref class FacultyDashboard : public System::Windows::Forms::Form
	{
	public:
		FacultyDashboard(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~FacultyDashboard()
		{
			if (components)
			{
				delete components;
			}
		}

	protected:
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Button^ btn_FacultyProfile;


	private: System::Windows::Forms::Button^ btnCoursematerials;
	private: System::Windows::Forms::Button^ button1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->btn_FacultyProfile = (gcnew System::Windows::Forms::Button());
			this->btnCoursematerials = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(333, 81);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(152, 37);
			this->button2->TabIndex = 1;
			this->button2->Text = L"Enter Grades";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &FacultyDashboard::button2_Click);
			// 
			// btn_FacultyProfile
			// 
			this->btn_FacultyProfile->Location = System::Drawing::Point(333, 182);
			this->btn_FacultyProfile->Name = L"btn_FacultyProfile";
			this->btn_FacultyProfile->Size = System::Drawing::Size(152, 40);
			this->btn_FacultyProfile->TabIndex = 3;
			this->btn_FacultyProfile->Text = L"Profile";
			this->btn_FacultyProfile->UseVisualStyleBackColor = true;
			this->btn_FacultyProfile->Click += gcnew System::EventHandler(this, &FacultyDashboard::btn_FacultyProfile_Click);
			// 
			// btnCoursematerials
			// 
			this->btnCoursematerials->Location = System::Drawing::Point(81, 81);
			this->btnCoursematerials->Name = L"btnCoursematerials";
			this->btnCoursematerials->Size = System::Drawing::Size(170, 37);
			this->btnCoursematerials->TabIndex = 4;
			this->btnCoursematerials->Text = L"Course materials";
			this->btnCoursematerials->UseVisualStyleBackColor = true;
			this->btnCoursematerials->Click += gcnew System::EventHandler(this, &FacultyDashboard::btnCoursematerials_Click);
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(81, 182);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(170, 40);
			this->button1->TabIndex = 5;
			this->button1->Text = L"Verify Students Enrollment";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &FacultyDashboard::button1_Click);
			// 
			// FacultyDashboard
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(611, 365);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->btnCoursematerials);
			this->Controls->Add(this->btn_FacultyProfile);
			this->Controls->Add(this->button2);
			this->Name = L"FacultyDashboard";
			this->Text = L"FacultyDashboard";
			this->Load += gcnew System::EventHandler(this, &FacultyDashboard::FacultyDashboard_Load);
			this->ResumeLayout(false);

		}


#pragma endregion
	private: System::Void FacultyDashboard_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void btn_FacultyProfile_Click(System::Object^ sender, System::EventArgs^ e) {
		FacultyProfile^ profileForm = gcnew FacultyProfile();
		profileForm->Show();
	

	}
	private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	
		GradeEntry^ GradeForm = gcnew GradeEntry();
		GradeForm->Show();

	}
private: System::Void btnCoursematerials_Click(System::Object^ sender, System::EventArgs^ e) {

	CourseMaterials^ MaterialForm = gcnew CourseMaterials();
	MaterialForm->Show();

}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {


	VerifyStudents^ verifyForm = gcnew VerifyStudents();
	verifyForm->Show();

}
};
}
