#pragma once
#include "StudentTranscript.h"

namespace UniversityApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Data::SqlClient;

	public ref class GenerateReport : public System::Windows::Forms::Form
	{
	public:
		GenerateReport(void)
		{
			InitializeComponent();
		}

	protected:
		~GenerateReport()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Button^ btnGenerateReport;
	private: System::Windows::Forms::TextBox^ GenID;

	private: System::Windows::Forms::DataGridView^ GridViewTranscript;
	private: System::Windows::Forms::Button^ btn_print;

	private:
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->btnGenerateReport = (gcnew System::Windows::Forms::Button());
			this->GenID = (gcnew System::Windows::Forms::TextBox());
			this->GridViewTranscript = (gcnew System::Windows::Forms::DataGridView());
			this->btn_print = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->GridViewTranscript))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold));
			this->label1->Location = System::Drawing::Point(9, 34);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(78, 16);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Student ID";
			// 
			// btnGenerateReport
			// 
			this->btnGenerateReport->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold));
			this->btnGenerateReport->Location = System::Drawing::Point(24, 87);
			this->btnGenerateReport->Name = L"btnGenerateReport";
			this->btnGenerateReport->Size = System::Drawing::Size(140, 30);
			this->btnGenerateReport->TabIndex = 4;
			this->btnGenerateReport->Text = L"Generate Report";
			this->btnGenerateReport->UseVisualStyleBackColor = true;
			this->btnGenerateReport->Click += gcnew System::EventHandler(this, &GenerateReport::btnGenerateReport_Click);
			// 
			// GenID
			// 
			this->GenID->Location = System::Drawing::Point(111, 33);
			this->GenID->Name = L"GenID";
			this->GenID->Size = System::Drawing::Size(169, 20);
			this->GenID->TabIndex = 5;
			// 
			// GridViewTranscript
			// 
			this->GridViewTranscript->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->GridViewTranscript->Location = System::Drawing::Point(12, 147);
			this->GridViewTranscript->Name = L"GridViewTranscript";
			this->GridViewTranscript->Size = System::Drawing::Size(304, 176);
			this->GridViewTranscript->TabIndex = 6;
			// 
			// btn_print
			// 
			this->btn_print->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->btn_print->Location = System::Drawing::Point(209, 87);
			this->btn_print->Name = L"btn_print";
			this->btn_print->Size = System::Drawing::Size(107, 30);
			this->btn_print->TabIndex = 7;
			this->btn_print->Text = L"Print Report ";
			this->btn_print->UseVisualStyleBackColor = true;
			this->btn_print->Click += gcnew System::EventHandler(this, &GenerateReport::btn_print_Click);
			// 
			// GenerateReport
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(391, 335);
			this->Controls->Add(this->btn_print);
			this->Controls->Add(this->GridViewTranscript);
			this->Controls->Add(this->GenID);
			this->Controls->Add(this->btnGenerateReport);
			this->Controls->Add(this->label1);
			this->Name = L"GenerateReport";
			this->Text = L"Generate Report";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->GridViewTranscript))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	private: System::Void btnGenerateReport_Click(System::Object^ sender, System::EventArgs^ e) {
		MySqlConnection^ sqlConn = gcnew MySqlConnection("datasource=localhost;port=3306;username=root;password=;database=university_management_system");
		String^ studentID = GenID->Text;

		if (String::IsNullOrWhiteSpace(studentID)) {
			MessageBox::Show("Please enter a valid Student ID.", "Input Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
			return;
		}

		try {
			sqlConn->Open();
			String^ query = "SELECT "
				"CONCAT(u.first_name, ' ', u.last_name) AS 'Student Name', "
				"s.major AS 'Student Major', "
				"c.course_name AS 'Course Name', "
				"IFNULL(g.grade, 'N/A') AS 'Grade' "
				"FROM students s "
				"JOIN users u ON s.student_id = u.user_id "
				"JOIN enrollments e ON s.student_id = e.student_id "
				"JOIN courses c ON e.course_id = c.course_id "
				"LEFT JOIN grades g ON e.enrollment_id = g.enrollment_id "
				"WHERE s.student_id = @StudentID;";

			MySqlCommand^ cmd = gcnew MySqlCommand(query, sqlConn);
			cmd->Parameters->AddWithValue("@StudentID", studentID);
			MySqlDataAdapter^ da = gcnew MySqlDataAdapter(cmd);
			DataTable^ dt = gcnew DataTable();
			da->Fill(dt);

			if (dt->Rows->Count > 0) {
				GridViewTranscript->Columns->Clear();
				GridViewTranscript->DataSource = dt;
				GridViewTranscript->AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode::Fill;
			}
			else {
				MessageBox::Show("No student found with the given Student ID.", "No Data", MessageBoxButtons::OK, MessageBoxIcon::Information);
			}

			sqlConn->Close();
		}
		catch (Exception^ ex) {
			MessageBox::Show("Error: " + ex->Message);
		}
	}
	private: System::Void btn_print_Click(System::Object^ sender, System::EventArgs^ e) {
		PrintPreviewDialog^ printPreview = gcnew PrintPreviewDialog();
		printPreview->Document = gcnew System::Drawing::Printing::PrintDocument();

		printPreview->Document->PrintPage += gcnew System::Drawing::Printing::PrintPageEventHandler(
			this, &GenerateReport::printDoc_GenerateReport_PrintPage);

		printPreview->ShowDialog();
	}

	private: System::Void printDoc_GenerateReport_PrintPage(System::Object^ sender, System::Drawing::Printing::PrintPageEventArgs^ e) {
		Graphics^ g = e->Graphics;
		SolidBrush^ printBrush = gcnew SolidBrush(Color::Black);

		int x = 50;
		int y = 50;
		int rowHeight = 20;

		// Print column headers
		for (int col = 0; col < GridViewTranscript->Columns->Count; col++) {
			g->DrawString(GridViewTranscript->Columns[col]->HeaderText, SystemFonts::DefaultFont, printBrush, x + (col * 100), y);
		}

		y += rowHeight;

		// Print rows
		for (int row = 0; row < GridViewTranscript->Rows->Count; row++) {
			for (int col = 0; col < GridViewTranscript->Columns->Count; col++) {
				if (GridViewTranscript->Rows[row]->Cells[col]->Value != nullptr) {
					g->DrawString(GridViewTranscript->Rows[row]->Cells[col]->Value->ToString(), SystemFonts::DefaultFont, printBrush, x + (col * 100), y);
				}
			}
			y += rowHeight;
		}
	}
	};
};


