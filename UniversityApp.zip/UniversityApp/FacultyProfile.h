

#pragma once

namespace UniversityApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for FacultyProfile
	/// </summary>
	public ref class FacultyProfile : public System::Windows::Forms::Form
	{
		MySqlConnection^ sqlConn = gcnew MySqlConnection();
		MySqlCommand^ sqlCmd = gcnew MySqlCommand();
		DataTable^ sqlDt = gcnew DataTable();
		MySqlDataAdapter^ sqlDtA = gcnew MySqlDataAdapter();

	public:
		MySqlDataReader^ sqlRd;

		FacultyProfile(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~FacultyProfile()
		{
			if (components)
			{
				delete components;
			}
		}

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;
		System::Windows::Forms::Label^ lblFullName;
		System::Windows::Forms::Label^ lblEmail;
		System::Windows::Forms::Label^ lblDepartment;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblFullName = (gcnew System::Windows::Forms::Label());
			this->lblEmail = (gcnew System::Windows::Forms::Label());
			this->lblDepartment = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// lblFullName
			// 
			this->lblFullName->AutoSize = true;
			this->lblFullName->Location = System::Drawing::Point(12, 20);
			this->lblFullName->Name = L"lblFullName";
			this->lblFullName->Size = System::Drawing::Size(60, 13);
			this->lblFullName->TabIndex = 0;
			this->lblFullName->Text = L"Full Name: ";
			// 
			// lblEmail
			// 
			this->lblEmail->AutoSize = true;
			this->lblEmail->Location = System::Drawing::Point(12, 50);
			this->lblEmail->Name = L"lblEmail";
			this->lblEmail->Size = System::Drawing::Size(38, 13);
			this->lblEmail->TabIndex = 1;
			this->lblEmail->Text = L"Email: ";
			// 
			// lblDepartment
			// 
			this->lblDepartment->AutoSize = true;
			this->lblDepartment->Location = System::Drawing::Point(12, 80);
			this->lblDepartment->Name = L"lblDepartment";
			this->lblDepartment->Size = System::Drawing::Size(68, 13);
			this->lblDepartment->TabIndex = 2;
			this->lblDepartment->Text = L"Department: ";
			// 
			// FacultyProfile
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->lblDepartment);
			this->Controls->Add(this->lblEmail);
			this->Controls->Add(this->lblFullName);
			this->Name = L"FacultyProfile";
			this->Text = L"FacultyProfile";
			this->Load += gcnew System::EventHandler(this, &FacultyProfile::FacultyProfile_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}

		/// <summary>
		/// Handles the Load event of the FacultyProfile form.
		/// </summary>
		System::Void FacultyProfile_Load(System::Object^ sender, System::EventArgs^ e)
		{
			try
			{
				// Update the connection string with your MySQL server details
				sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";
				sqlConn->Open();

				// Assume 'user_id' is already available or retrieved from session or login
				String^ user_id = "1"; // Replace with actual user_id value

				// SQL query to retrieve the full name, email, and department name
				sqlCmd->CommandText = "SELECT CONCAT(U.first_name, ' ', U.last_name) AS FullName, U.email, D.department_name "
					"FROM Users U "
					"INNER JOIN Faculty F ON U.user_id = F.faculty_id "
					"INNER JOIN Department D ON F.department_id = D.department_id "
					"WHERE U.user_id = @user_id";

				sqlCmd->Connection = sqlConn;
				sqlCmd->Parameters->AddWithValue("@user_id", user_id);

				sqlRd = sqlCmd->ExecuteReader();

				if (sqlRd->Read())
				{
					lblFullName->Text = "Full Name: " + sqlRd["FullName"]->ToString();
					lblEmail->Text = "Email: " + sqlRd["email"]->ToString();
					lblDepartment->Text = "Department: " + sqlRd["department_name"]->ToString();
				}

				sqlRd->Close();
			}
			catch (Exception^ ex)
			{
				MessageBox::Show("Error: " + ex->Message);
			}
			finally
			{
				sqlConn->Close();
			}
		}
	};
}
