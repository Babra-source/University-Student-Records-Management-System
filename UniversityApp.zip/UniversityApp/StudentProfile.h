#pragma once

namespace ManagementSystemApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for StudentProfile
	/// </summary>
	public ref class StudentProfile : public System::Windows::Forms::Form
	{
	public:
		StudentProfile(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~StudentProfile()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::DateTimePicker^ StudentDateBirth;


	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::PictureBox^ StudentPicture;

	private: System::Windows::Forms::TextBox^ StudentMajor;

	private: System::Windows::Forms::Button^ btnSave;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::DateTimePicker^ dateTimePicker2;
	private: System::Windows::Forms::TextBox^ SudentFirstName;
	private: System::Windows::Forms::TextBox^ StudentLastName;


	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->StudentDateBirth = (gcnew System::Windows::Forms::DateTimePicker());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->StudentPicture = (gcnew System::Windows::Forms::PictureBox());
			this->StudentMajor = (gcnew System::Windows::Forms::TextBox());
			this->btnSave = (gcnew System::Windows::Forms::Button());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->dateTimePicker2 = (gcnew System::Windows::Forms::DateTimePicker());
			this->SudentFirstName = (gcnew System::Windows::Forms::TextBox());
			this->StudentLastName = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->StudentPicture))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(4, 13);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(82, 16);
			this->label1->TabIndex = 0;
			this->label1->Text = L"First Name";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(4, 45);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(81, 16);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Last Name";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(4, 120);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(38, 13);
			this->label4->TabIndex = 3;
			this->label4->Text = L"Major";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(0, 176);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(87, 13);
			this->label5->TabIndex = 4;
			this->label5->Text = L"Profile Picture";
			this->label5->Click += gcnew System::EventHandler(this, &StudentProfile::label5_Click);
			// 
			// StudentDateBirth
			// 
			this->StudentDateBirth->Location = System::Drawing::Point(126, 88);
			this->StudentDateBirth->Name = L"StudentDateBirth";
			this->StudentDateBirth->Size = System::Drawing::Size(200, 20);
			this->StudentDateBirth->TabIndex = 5;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(3, 88);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(92, 16);
			this->label3->TabIndex = 6;
			this->label3->Text = L"Date of Birth";
			// 
			// StudentPicture
			// 
			this->StudentPicture->BackColor = System::Drawing::SystemColors::ControlDark;
			this->StudentPicture->Location = System::Drawing::Point(126, 163);
			this->StudentPicture->Name = L"StudentPicture";
			this->StudentPicture->Size = System::Drawing::Size(100, 50);
			this->StudentPicture->TabIndex = 7;
			this->StudentPicture->TabStop = false;
			this->StudentPicture->Click += gcnew System::EventHandler(this, &StudentProfile::pictureBox1_Click);
			// 
			// StudentMajor
			// 
			this->StudentMajor->Location = System::Drawing::Point(126, 120);
			this->StudentMajor->Name = L"StudentMajor";
			this->StudentMajor->Size = System::Drawing::Size(100, 20);
			this->StudentMajor->TabIndex = 8;
			// 
			// btnSave
			// 
			this->btnSave->Location = System::Drawing::Point(140, 313);
			this->btnSave->Name = L"btnSave";
			this->btnSave->Size = System::Drawing::Size(75, 23);
			this->btnSave->TabIndex = 9;
			this->btnSave->Text = L"Save Profile";
			this->btnSave->UseVisualStyleBackColor = true;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(3, 241);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(117, 16);
			this->label6->TabIndex = 10;
			this->label6->Text = L"Enrollment Date";
			// 
			// dateTimePicker2
			// 
			this->dateTimePicker2->Location = System::Drawing::Point(126, 237);
			this->dateTimePicker2->Name = L"dateTimePicker2";
			this->dateTimePicker2->Size = System::Drawing::Size(200, 20);
			this->dateTimePicker2->TabIndex = 11;
			this->dateTimePicker2->ValueChanged += gcnew System::EventHandler(this, &StudentProfile::dateTimePicker2_ValueChanged);
			// 
			// SudentFirstName
			// 
			this->SudentFirstName->Location = System::Drawing::Point(126, 13);
			this->SudentFirstName->Name = L"SudentFirstName";
			this->SudentFirstName->Size = System::Drawing::Size(142, 20);
			this->SudentFirstName->TabIndex = 12;
			// 
			// StudentLastName
			// 
			this->StudentLastName->Location = System::Drawing::Point(126, 45);
			this->StudentLastName->Name = L"StudentLastName";
			this->StudentLastName->Size = System::Drawing::Size(142, 20);
			this->StudentLastName->TabIndex = 13;
			// 
			// StudentProfile
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(386, 372);
			this->Controls->Add(this->StudentLastName);
			this->Controls->Add(this->SudentFirstName);
			this->Controls->Add(this->dateTimePicker2);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->btnSave);
			this->Controls->Add(this->StudentMajor);
			this->Controls->Add(this->StudentPicture);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->StudentDateBirth);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"StudentProfile";
			this->Text = L"StudentProfile";
			this->Load += gcnew System::EventHandler(this, &StudentProfile::StudentProfile_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->StudentPicture))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label5_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void dateTimePicker2_ValueChanged(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void StudentProfile_Load(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void pictureBox1_Click(System::Object^ sender, System::EventArgs^ e) {
	}
};
}
