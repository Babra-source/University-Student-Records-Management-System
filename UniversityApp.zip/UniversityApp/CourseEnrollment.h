#pragma once

namespace UniversityApp {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace MySql::Data::MySqlClient;

	/// <summary>
	/// Summary for CourseEnrollment
	/// </summary>
	public ref class CourseEnrollment : public System::Windows::Forms::Form
	{

		MySqlConnection^ sqlConn = gcnew MySqlConnection();
		MySqlCommand^ sqlCmd = gcnew MySqlCommand();
		DataTable^ sqlDt = gcnew DataTable();
		MySqlDataAdapter^ sqlDtA = gcnew MySqlDataAdapter();
	private: System::Windows::Forms::Button^ BtnStudentEnroll;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::TextBox^ EnrollStudentId;
	public:
		MySqlDataReader^ sqlRd;
		CourseEnrollment(void)
		{
			InitializeComponent();
			LoadCourses();  // Call the method to load courses in the constructor
			SubmitEnrollment();
			//int studentId;
			//int courseId;
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~CourseEnrollment()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::ComboBox^ Coursedropdown;

	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->Coursedropdown = (gcnew System::Windows::Forms::ComboBox());
			this->BtnStudentEnroll = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->EnrollStudentId = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(12, 86);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(162, 20);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Available Courses :";
			// 
			// Coursedropdown
			// 
			this->Coursedropdown->AutoCompleteCustomSource->AddRange(gcnew cli::array< System::String^  >(1) { L"DSA" });
			this->Coursedropdown->FormattingEnabled = true;
			this->Coursedropdown->Location = System::Drawing::Point(210, 85);
			this->Coursedropdown->Name = L"Coursedropdown";
			this->Coursedropdown->Size = System::Drawing::Size(169, 21);
			this->Coursedropdown->TabIndex = 1;
			this->Coursedropdown->SelectedIndexChanged += gcnew System::EventHandler(this, &CourseEnrollment::comboBox1_SelectedIndexChanged);
			// 
			// BtnStudentEnroll
			// 
			this->BtnStudentEnroll->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->BtnStudentEnroll->Location = System::Drawing::Point(156, 163);
			this->BtnStudentEnroll->Name = L"BtnStudentEnroll";
			this->BtnStudentEnroll->Size = System::Drawing::Size(126, 23);
			this->BtnStudentEnroll->TabIndex = 2;
			this->BtnStudentEnroll->Text = L"Enroll Now ";
			this->BtnStudentEnroll->UseVisualStyleBackColor = false;
			this->BtnStudentEnroll->Click += gcnew System::EventHandler(this, &CourseEnrollment::BtnStudentEnroll_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(12, 23);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(94, 20);
			this->label2->TabIndex = 3;
			this->label2->Text = L"StudentId ";
			// 
			// EnrollStudentId
			// 
			this->EnrollStudentId->Location = System::Drawing::Point(210, 22);
			this->EnrollStudentId->Name = L"EnrollStudentId";
			this->EnrollStudentId->Size = System::Drawing::Size(169, 20);
			this->EnrollStudentId->TabIndex = 4;
			// 
			// CourseEnrollment
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(469, 261);
			this->Controls->Add(this->EnrollStudentId);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->BtnStudentEnroll);
			this->Controls->Add(this->Coursedropdown);
			this->Controls->Add(this->label1);
			this->Name = L"CourseEnrollment";
			this->Text = L"CourseEnrollment";
			this->Load += gcnew System::EventHandler(this, &CourseEnrollment::CourseEnrollment_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion


	private: System::Void comboBox1_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
		// Handle the selection change event here
	}

		   // Method to load courses into the ComboBox
	private: System::Void LoadCourses()
	{
		try {
			if (sqlConn->State != ConnectionState::Closed) {
				sqlConn->Close();
			}

			sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";
			sqlConn->Open();

			sqlCmd->CommandText = "SELECT course_id, course_name FROM courses";
			sqlCmd->Connection = sqlConn;

			sqlRd = sqlCmd->ExecuteReader();

			// Clear previous items in case this method is called again
			Coursedropdown->Items->Clear();
			courseDictionary = gcnew System::Collections::Generic::Dictionary<String^, String^>(); // Initialize the dictionary

			// Loop through the data reader and add course names to the ComboBox
			while (sqlRd->Read()) {
				String^ courseId = sqlRd->GetString(0);
				String^ courseName = sqlRd->GetString(1);

				Coursedropdown->Items->Add(courseName); // Add course name to the dropdown
				courseDictionary->Add(courseName, courseId); // Add the course name and ID to the dictionary
			}

			sqlRd->Close();
			sqlConn->Close();
		}
		catch (Exception^ ex) {
			MessageBox::Show("Error: " + ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
	}

		   // Declare a dictionary to store course names and their corresponding course IDs
	private: System::Collections::Generic::Dictionary<String^, String^>^ courseDictionary;

		   private: System::Void SubmitEnrollment()
		   {
			   try {
				   if (String::IsNullOrWhiteSpace(EnrollStudentId->Text) || Coursedropdown->SelectedIndex == -1) {
					   MessageBox::Show("Please provide a valid Student ID and select a course.", "Validation Error", MessageBoxButtons::OK, MessageBoxIcon::Warning);
					   return;
				   }

				   sqlConn->ConnectionString = "datasource=localhost;port=3306;username=root;password=;database=university_management_system";
				   sqlConn->Open();

				   // Get the selected course name from the ComboBox
				   String^ selectedCourseName = Coursedropdown->SelectedItem->ToString();

				   // Use the dictionary to get the corresponding course_id
				   String^ courseId = courseDictionary[selectedCourseName];

				   sqlCmd->CommandText = "INSERT INTO enrollments (student_id, course_id, enrollment_status) VALUES (@studentId, @courseId, 'pending')";
				   sqlCmd->Connection = sqlConn;
				   sqlCmd->Parameters->Clear();
				   sqlCmd->Parameters->AddWithValue("@studentId", EnrollStudentId->Text);
				   sqlCmd->Parameters->AddWithValue("@courseId", courseId);

				   sqlCmd->ExecuteNonQuery();
				   MessageBox::Show("Enrollment submitted successfully.", "Success", MessageBoxButtons::OK, MessageBoxIcon::Information);

				   sqlConn->Close();
			   }
			   catch (Exception^ ex) {
				   MessageBox::Show("Error: " + ex->Message, "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
			   }
		   }


		   // CourseEnrollment_Load can be kept for additional load events if necessary
	private: System::Void CourseEnrollment_Load(System::Object^ sender, System::EventArgs^ e) {
		// You can call LoadCourses here too if you want to reload data on every form load
		LoadCourses();
	}
	private: System::Void BtnStudentEnroll_Click(System::Object^ sender, System::EventArgs^ e) {
		SubmitEnrollment();
	}
	};
}
