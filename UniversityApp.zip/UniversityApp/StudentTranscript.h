#pragma once

namespace UniversityApp {

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;
    using namespace MySql::Data::MySqlClient;

    public ref class StudentTranscript : public System::Windows::Forms::Form
    {

        MySqlConnection^ sqlConn = gcnew MySqlConnection();
        MySqlCommand^ sqlCmd = gcnew MySqlCommand();
        DataTable^ sqlDt = gcnew DataTable();
        MySqlDataAdapter^ sqlDtA = gcnew MySqlDataAdapter();


    public:

        MySqlDataReader^ sqlRd;

        StudentTranscript(void)
        {
            InitializeComponent();
        }

    protected:
        ~StudentTranscript()
        {
            if (components)
            {
                delete components;
            }
        }
    private: System::ComponentModel::BackgroundWorker^ backgroundWorker1;
    private: System::Windows::Forms::DataGridView^ GridViewTranscript;
    private: System::Windows::Forms::Label^ label1;
    private: System::Windows::Forms::TextBox^ TranscriptStudentID;

    private: System::Windows::Forms::Label^ label2;
    private: System::Windows::Forms::Button^ btn_ShowTranscript;

    protected:

    private:
        System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
        void InitializeComponent(void)
        {
            System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(StudentTranscript::typeid));
            this->backgroundWorker1 = (gcnew System::ComponentModel::BackgroundWorker());
            this->GridViewTranscript = (gcnew System::Windows::Forms::DataGridView());
            this->label1 = (gcnew System::Windows::Forms::Label());
            this->TranscriptStudentID = (gcnew System::Windows::Forms::TextBox());
            this->label2 = (gcnew System::Windows::Forms::Label());
            this->btn_ShowTranscript = (gcnew System::Windows::Forms::Button());
            (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->GridViewTranscript))->BeginInit();
            this->SuspendLayout();
            // 
            // GridViewTranscript
            // 
            this->GridViewTranscript->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
            this->GridViewTranscript->Location = System::Drawing::Point(29, 112);
            this->GridViewTranscript->Name = L"GridViewTranscript";
            this->GridViewTranscript->Size = System::Drawing::Size(325, 258);
            this->GridViewTranscript->TabIndex = 0;
            // 
            // label1
            // 
            this->label1->AutoSize = true;
            this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
                static_cast<System::Byte>(0)));
            this->label1->Location = System::Drawing::Point(198, 9);
            this->label1->Name = L"label1";
            this->label1->Size = System::Drawing::Size(89, 20);
            this->label1->TabIndex = 1;
            this->label1->Text = L"Transcript";
            // 
            // TranscriptStudentID
            // 
            this->TranscriptStudentID->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 12, System::Drawing::FontStyle::Regular,
                System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
            this->TranscriptStudentID->Location = System::Drawing::Point(88, 64);
            this->TranscriptStudentID->Multiline = true;
            this->TranscriptStudentID->Name = L"TranscriptStudentID";
            this->TranscriptStudentID->Size = System::Drawing::Size(161, 20);
            this->TranscriptStudentID->TabIndex = 2;
            // 
            // label2
            // 
            this->label2->AutoSize = true;
            this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
                static_cast<System::Byte>(0)));
            this->label2->Location = System::Drawing::Point(3, 64);
            this->label2->Name = L"label2";
            this->label2->Size = System::Drawing::Size(70, 13);
            this->label2->TabIndex = 3;
            this->label2->Text = L"Student Id ";
            // 
            // btn_ShowTranscript
            // 
            this->btn_ShowTranscript->Location = System::Drawing::Point(333, 61);
            this->btn_ShowTranscript->Name = L"btn_ShowTranscript";
            this->btn_ShowTranscript->Size = System::Drawing::Size(48, 23);
            this->btn_ShowTranscript->TabIndex = 4;
            this->btn_ShowTranscript->Text = L"Submit";
            this->btn_ShowTranscript->UseVisualStyleBackColor = true;
            this->btn_ShowTranscript->Click += gcnew System::EventHandler(this, &StudentTranscript::btn_ShowTranscript_Click);
            // 
            // StudentTranscript
            // 
            this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
            this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
            this->BackColor = System::Drawing::SystemColors::ActiveCaption;
            this->ClientSize = System::Drawing::Size(541, 371);
            this->Controls->Add(this->btn_ShowTranscript);
            this->Controls->Add(this->label2);
            this->Controls->Add(this->TranscriptStudentID);
            this->Controls->Add(this->label1);
            this->Controls->Add(this->GridViewTranscript);
            this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
            this->Name = L"StudentTranscript";
            this->Text = L"StudentTranscript";
            this->Load += gcnew System::EventHandler(this, &StudentTranscript::StudentTranscript_Load);
            (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->GridViewTranscript))->EndInit();
            this->ResumeLayout(false);
            this->PerformLayout();

        }
#pragma endregion

    private: System::Void StudentTranscript_Load(System::Object^ sender, System::EventArgs^ e) {

    }
    private: System::Void btn_ShowTranscript_Click(System::Object^ sender, System::EventArgs^ e) {
        MySqlConnection^ sqlConn = gcnew MySqlConnection("datasource=localhost;port=3306;username=root;password=;database=university_management_system");
        String^ studentID = TranscriptStudentID->Text;

        if (String::IsNullOrWhiteSpace(studentID)) {
            MessageBox::Show("Please enter a valid Student ID.", "Input Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
            return;
        }

        try {
            sqlConn->Open();
            String^ query = "SELECT "
                "CONCAT(u.first_name, ' ', u.last_name) AS 'Student Name', "
                "s.major AS 'Student Major', "
                "c.course_name AS 'Course Name', "
                "IFNULL(g.grade, 'N/A') AS 'Grade' "
                "FROM students s "
                "JOIN users u ON s.student_id = u.user_id "
                "JOIN enrollments e ON s.student_id = e.student_id "
                "JOIN courses c ON e.course_id = c.course_id "
                "LEFT JOIN grades g ON e.enrollment_id = g.enrollment_id "
                "WHERE s.student_id = @StudentID;";

            MySqlCommand^ cmd = gcnew MySqlCommand(query, sqlConn);
            cmd->Parameters->AddWithValue("@StudentID", studentID);
            MySqlDataAdapter^ da = gcnew MySqlDataAdapter(cmd);
            DataTable^ dt = gcnew DataTable();
            da->Fill(dt);

            if (dt->Rows->Count > 0) {
                GridViewTranscript->Columns->Clear();
                GridViewTranscript->DataSource = dt;
                GridViewTranscript->AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode::Fill;
            }
            else {
                MessageBox::Show("No student found with the given Student ID.", "No Data", MessageBoxButtons::OK, MessageBoxIcon::Information);
            }

            sqlConn->Close();
        }
        catch (Exception^ ex) {
            MessageBox::Show("Error: " + ex->Message);
        }
    }

    };
}
